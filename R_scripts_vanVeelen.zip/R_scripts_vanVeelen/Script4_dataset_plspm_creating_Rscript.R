### This R script belongs to van Veelen et al. The microbial environment modulates non-genetic maternal effects on egg immunity


### With this script microbial community data and immune function data have been organised and reshaped to create the input file for PLS-PM path model analysis.
 
### For questions, contact Pieter van Veelen (pietervanveelen2@gmail.com)


##############################################

### data organisation for discriminant function analysis and path analysis Sander van Doorn ###

# Input data
physeq_egg_top80

phyloseq-class experiment-level object
otu_table()   OTU Table:         [ 3423 taxa and 198 samples ]
sample_data() Sample Data:       [ 198 samples by 78 sample variables ]
tax_table()   Taxonomy Table:    [ 3423 taxa by 7 taxonomic ranks ]
phy_tree()    Phylogenetic Tree: [ 3423 tips and 3422 internal nodes ]

physeq_egg_top80_vst

phyloseq-class experiment-level object
otu_table()   OTU Table:         [ 3423 taxa and 198 samples ]
sample_data() Sample Data:       [ 198 samples by 78 sample variables ]
tax_table()   Taxonomy Table:    [ 3423 taxa by 7 taxonomic ranks ]
phy_tree()    Phylogenetic Tree: [ 3423 tips and 3422 internal nodes ]

physeq_cloaca_top90

phyloseq-class experiment-level object
otu_table()   OTU Table:         [ 2079 taxa and 196 samples ]
sample_data() Sample Data:       [ 196 samples by 78 sample variables ]
tax_table()   Taxonomy Table:    [ 2079 taxa by 7 taxonomic ranks ]
phy_tree()    Phylogenetic Tree: [ 2079 tips and 2078 internal nodes ]

physeq_cloaca_top90_t5



#### Female data processing ####

## create data set for females at t5 (top90% = 40 females)
physeq_cloaca_top90_t5

# convert OTU table into data frame object with females as rows
f.otudata.t5 <- data.frame(t(otu_table(physeq_cloaca_top90_t5)))
# remove "X" from sample IDs (not needed)
#rownames(f.otudata.t5) <- sapply(strsplit(rownames(f.otudata.t5),"X"),"[",2)

# create relabund data

physeq_cloaca_top90_t5_rel <- transform_sample_counts(physeq_cloaca_top90_t5, function(x) 100*x/sum(x))

sample_sums(physeq_cloaca_top90_t5_rel)

# convert rel abund OTU table into data frame object with females as rows
f.otudata.t_rel <- data.frame(t(otu_table(physeq_cloaca_top90_t5_rel)))
# remove "X" from sample IDs (not needed)

# add an "f" (female) tag to all OTUs belongning to the female cloacal data to separate them later from eggshell OTUs, without duplicate OTU names
colnames(f.otudata.t5) <- paste0("f_", colnames(f.otudata.t5))
colnames(f.otudata.t_rel) <- paste0("f_", colnames(f.otudata.t_rel))

## convert sample data (metadata) table into data frame object with females as rows (should be 40 individuals; check if same females are present in OTU data)
f.sampledata.t5 <- data.frame(sample_data(physeq_cloaca_top90_t5), row.names = "SampleID")
f.sampledata.t5$replicate <- factor(paste0(f.sampledata.t5$room, f.sampledata.t5$side))
nrow(f.sampledata.t5) # 40 rows

# select rows to be combined with OTU data
f.sampledata.t5_ss <- subset(f.sampledata.t5, select = c("exp", "replicate", "ring_ID", "condition", "agg_titre", "IgYmean", "lysis_titre", "hp"))
nrow(f.sampledata.t5_ss) # 40 rows


## combine OTU data with 
# check if rownames are identical
rownames(f.otudata.t5)
rownames(f.sampledata.t5_ss)

identical(rownames(f.otudata.t5), rownames(f.sampledata.t5_ss))
identical(rownames(f.otudata.t_rel), rownames(f.sampledata.t5_ss))

# TRUE
# merge data frames by rownames (SampleID)
f.data <- merge(f.otudata.t5,f.sampledata.t5_ss, by = "row.names")
f.data.rel <- merge(f.otudata.t_rel,f.sampledata.t5_ss, by = "row.names")


#### Egg data processing ####


## create data set for females at t5 (top90% = 40 females)
physeq_egg_top80
summary(sample_sums(physeq_egg_top80))

# convert OTU table into data frame object with females as rows
e.otudata <- data.frame(t(otu_table(physeq_egg_top80)))
# remove "X" from sample IDs (not needed)
#rownames(e.otudata) <- sapply(strsplit(rownames(e.otudata),"X"),"[",2)

physeq_egg_top80_rel <- transform_sample_counts(physeq_egg_top80, function(x) 100*x/sum(x))

sample_sums(physeq_egg_top80_rel)

e.otudata.rel <- data.frame(t(otu_table(physeq_egg_top80_rel)))


# add an "e" (egg) tag to all OTUs belongning to the female cloacal data to separate them later from eggshell OTUs, without duplicate OTU names
colnames(e.otudata) <- paste0("e_", colnames(e.otudata))
colnames(e.otudata.rel) <- paste0("e_", colnames(e.otudata.rel))

## convert sample data (metadata) table into data frame object with females as rows (should be 40 individuals; check if same females are present in OTU data)
e.sampledata <- data.frame(sample_data(physeq_egg_top80), row.names = "SampleID")
e.sampledata$replicate <- factor(paste0(e.sampledata$room, e.sampledata$treatment))
nrow(e.sampledata) # 198 rows

# select rows to be combined with OTU data
colnames(e.sampledata)
e.sampledata_ss <- subset(e.sampledata, select = c("ring_ID", "clutch_nr", "egg_nr", "IgYmean_yolk", "lyso", "ovotransferrin","pH"))
nrow(e.sampledata_ss) # 198 rows

e.sampledata_ss$egg_nr[c(4,84)] <- c("3", "4")
droplevels(e.sampledata_ss$egg_nr)


## combine OTU data with 
# check if rownames are identical
rownames(e.otudata)
rownames(e.sampledata_ss)

identical(rownames(e.otudata), rownames(e.sampledata_ss))
identical(rownames(e.otudata.rel), rownames(e.sampledata_ss))

# TRUE
# merge data frames by rownames (SampleID)
e.data <- merge(e.otudata,e.sampledata_ss, by = "row.names")
e.data.rel <- merge(e.otudata.rel,e.sampledata_ss, by = "row.names")
dim(e.data.rel)

#### Concatenate f.data and e.data ####

# check intersecting ring numbers

intersect(f.data$ring_ID, e.data$ring_ID)

[1] "4428" "4414" "4432" "4280" "4445" "4232" "3804" "3666"

nrow(subset(f.data, select = "ring_ID" %in% intersect(f.data$ring_ID, e.data$ring_ID)))

all.data.rel <- merge(f.data.rel, e.data.rel, by = "ring_ID", sort = TRUE, all.y = TRUE)

# Check dimensions
dim(f.data)
40 290
dim(e.data)
198 3431 (incl. 1 Row.names.x)
dim(all.data.rel)
198 3720 (incl. 1 Row.names.x; 1 Row.names.y, -1 ring_id)) 
# Check column names
all.data.rel[, !grepl("e_", names(all.data.rel))]

# change column names for clarity
row.names(all.data.rel)
all.data$exp ifelse(all.data$exp == "treatment", "low", "high")

colnames(all.data.rel)[1] <- "femaleID"
colnames(all.data.rel)[2] <- "f_sampleID"
colnames(all.data.rel)[284] <- "exp_group"
colnames(all.data.rel)[286] <- "f_resid_mass"
colnames(all.data.rel)[287] <- "f_agg_titre"
colnames(all.data.rel)[288] <- "f_IgY_plasma"
colnames(all.data.rel)[289] <- "f_lysis_titre"
colnames(all.data.rel)[290] <- "f_haptoglobin"
colnames(all.data.rel)[291] <- "eggID"
colnames(all.data.rel)[3715] <- "e_clutch_nr"
colnames(all.data.rel)[3716] <- "e_egg_nr"
colnames(all.data.rel)[3717] <- "e_IgY_yolk"
colnames(all.data.rel)[3718] <- "e_lysozyme"
colnames(all.data.rel)[3719] <- "e_ovotransferrin"
colnames(all.data.rel)[3720] <- "e_pH"

# check if new names are ok
all.data[is.na(all.data$exp),c(1, 2, 284:291, 3715:3720)]

identical(all.data$femaleID, all.data.rel$femaleID)

all.data.rel[,c(1, 2, 284:291, 3715:3720)] <- all.data[,c(1, 2, 284:291, 3715:3720)]

all.data$exp_group <- ifelse(all.data$exp_group == "treatment", "low", ifelse(all.data$exp_group == "control", "high", ifelse(all.data$exp_group == "high", "high", "low")))

all.data$e_clutch_nr
all.data$e_egg_nr

# NA's in females 
## check for NAs
# egg df to fill gaps
all.data[is.na(all.data$exp),c(1, 2, 284:291, 3715:3720)] 
all.data[is.na(all.data$replicate),c(1, 2, 284:291, 3715:3720)]
all.data[is.na(all.data$f_sampleID), c(1, 2, 284:291, 3715:3720)] 
all.data[is.na(all.data$f_resid_mass), c(1, 2, 284:291, 3715:3720)] 
all.data[is.na(all.data$f_IgY_plasma), c(1, 2, 284:291, 3715:3720)] 
all.data[is.na(all.data$eggID), c(1, 2, 284:291, 3715:3720)] 
all.data[is.na(all.data$e_clutch_nr), c(1, 2, 284:291, 3715:3720)] 
all.data[is.na(all.data$e_egg_nr), c(1, 2, 284:291, 3715:3720)] 

# solve from Egg data metadata (physeq_metadata)
  View(physeq_metadata) #4238 = high, 4250 = low, 4434 = low, 4454 = low
  all.data.rel[c(91:96,103:106,144, 153:156),]$exp_group <- c("high", "high", "high", "high", "high", "high", "low", "low", "low", "low", "low", "low", "low", "low", "low")
  all.data.rel[c(91:96,103:106,144, 153:156),]$replicate <- c("NR", "NR", "NR", "NR", "NR", "NR", "ZL", "ZL", "ZL", "ZL", "ZL", "ZL", "ZL", "ZL", "ZL")
  all.data.rel[c(91:96,103:106,144, 153:156),]$f_sampleID <- c("6314A.S205", "6314A.S205", "6314A.S205", "6314A.S205", "6314A.S205", "6314A.S205", "6314A.S217", "6314A.S217", "6314A.S217", "6314A.S217", "6314A.S211", "6314A.S216", "6314A.S216", "6314A.S216", "6314A.S216")
  all.data.rel[c(91:96,103:106,144, 153:156),]$f_resid_mass <- c(-0.3848341, -0.3848341, -0.3848341, -0.3848341, -0.3848341, -0.3848341, -0.8326227, -0.8326227, -0.8326227, -0.8326227, 2.41388, -0.2249045, -0.2249045, -0.2249045, -0.2249045)
  all.data[c(45:51,65:70),]$f_resid_mass <- c(0.08866364,0.08866364,0.08866364,0.08866364,0.08866364,0.08866364,0.08866364,0.9937387,0.9937387,0.9937387,0.9937387,0.9937387,0.9937387)
  
all.data.rel[, c(1, 2, 284:291, 3715:3720)] 

dim(all.data)


# write dataframe as txt
write.table(all.data, "data_microbiome_immunity_females_eggs_20180614.txt", sep = "\t", dec = ".", col.names = T, row.names = F)

colnames(all.data[3717])

# writre r file

saveRDS(all.data.rel, "data_microbiome_immunity_females_eggs_20180614.rds")
write.table(all.data.rel, "data_microbiome.rel_immunity_females_eggs_20180614.txt", sep = "\t", dec = ".", col.names = T, row.names = F)
