### This R script belongs to van Veelen et al. The microbial environment modulates non-genetic maternal effects on egg immunity


### With this script microbial diversity analyses have been performed from a phyloseq object. Immune function data have been analysed, and then linked to microbiome data.
 
### For questions, contact Pieter van Veelen (pietervanveelen2@gmail.com)


##############################################


### relationships between egg immunity and maternal and eggshell microbiota ###

# input file
load(file="../../../../../Rdata backups/CH6_Egg_immunity_zf/CH6_zf_egg_immunity/zf_eggshell_cloacal_soil_physeq_data.rda")
physeq_data

### create SampleType-specific phyloseq objects ###
physeq_egg <- subset_samples(physeq_data, SampleType == "egg")
physeq_egg <- prune_taxa(taxa_sums(physeq_egg) > 0, physeq_egg)

physeq_egg

    phyloseq-class experiment-level object
    otu_table()   OTU Table:         [ 3573 taxa and 265 samples ]
    sample_data() Sample Data:       [ 265 samples by 78 sample variables ]
    tax_table()   Taxonomy Table:    [ 3573 taxa by 7 taxonomic ranks ]
    phy_tree()    Phylogenetic Tree: [ 3573 tips and 3572 internal nodes ]


physeq_cloaca <- subset_samples(physeq_data, SampleType == "cloaca")
physeq_cloaca <- prune_taxa(taxa_sums(physeq_cloaca) > 0, physeq_cloaca)

physeq_cloaca

    headphyloseq-class experiment-level object
    otu_table()   OTU Table:         [ 2079 taxa and 228 samples ]
    sample_data() Sample Data:       [ 228 samples by 78 sample variables ]
    tax_table()   Taxonomy Table:    [ 2079 taxa by 7 taxonomic ranks ]
    phy_tree()    Phylogenetic Tree: [ 2079 tips and 2078 internal nodes ]

# summary stats to visualise data structures
hist(sample_sums(physeq_egg))

summary(sample_sums(physeq_egg)) 
quantile(summary(sample_sums(physeq_egg)), 0.1) # 10th%-ile = 157.5
quantile(summary(sample_sums(physeq_egg)), 0.2) # 20th%-ile = 313


hist(sample_sums(physeq_cloaca))

summary(sample_sums(physeq_cloaca)) 
quantile(summary(sample_sums(physeq_cloaca)), 0.1) # 10th%-ile = 676.375
quantile(summary(sample_sums(physeq_cloaca)), 0.2) # 20th%-ile = 1344.75


## Based on the distributions of sample coverage per SampleType, we decided
## to select the top 80% of eggshell samples, the top 90% of cloacal samples and 
## all soil samples for compositional comparisons among these SampleTypes.
## Following McMurdie and Holmes 2014 we do not rarefy data.
## to achieve the necessary data, we first prune the samples passing the quantile thresholds, 
## then extract the sample names that should remain, and finally we subset these samples 
## from the combinatory phyloseq object    

# filter SampleType-specific phyloseq objects    
physeq_egg_top80 <- prune_samples(sample_sums(physeq_egg) > 313, physeq_egg) # 198 eggs retained; 67 lost
physeq_cloaca_top90 <- prune_samples(sample_sums(physeq_cloaca) > 676, physeq_cloaca) # 196 cloacae retained; 32 lost

# extract the sample names
list_retain_egg <- c(as.character(sample_data(physeq_egg_top80)$SampleID))
list_retain_cloaca <- c(as.character(sample_data(physeq_cloaca_top90)$SampleID))

list_SampleType_compar <- c(list_retain_egg,list_retain_cloaca)

# phyloseq object with filtered egg and cloacal samples
physeq_SampleType_compar <- subset_samples(physeq_data, SampleID %in% list_SampleType_compar) # retaining 394 samples


## before VST procedure, check if median group (i.e. egg, cloaca, soil) coverage does not differ by more than 3 times
## cf. Weiss et al. 2015 PeerJ

ss_egg80 <- sample_sums(physeq_egg_top80)
ss_cloacal90 <- sample_sums(physeq_cloaca_top90)

kruskal.test(list(ss_egg80, ss_cloacal90)) # medians differ: Kruskal-Wallis rank sum test

Kruskal-Wallis rank sum test

data:  list(ss_egg80, ss_cloacal90)
Kruskal-Wallis chi-squared = 12.469, df = 1, p-value = 0.0004138

sapply(list(ss_egg80, ss_cloacal90), FUN = summary)

[,1]      [,2]
Min.      339.00   726.000
1st Qu.  1068.50  1789.250
Median   3101.00  4360.500
Mean     4642.47  6719.531
3rd Qu.  6433.25  8404.250
Max.    24815.00 78049.000

## medians vary max. (4360.500/3101.00 = 1.406159), which is borderline within acceptable range (max = 3x, see Weiss et al 2015)
# continue with VST



### Variance-stabilising transformation using DESeq2 ###

  ## eggs only

    ## Input dataframes:
    physeq_egg_top80 <- prune_taxa(taxa_sums(physeq_egg_top80) > 0, physeq_egg_top80)

    phyloseq-class experiment-level object
    otu_table()   OTU Table:         [ 3423 taxa and 198 samples ]
    sample_data() Sample Data:       [ 198 samples by 78 sample variables ]
    tax_table()   Taxonomy Table:    [ 3423 taxa by 7 taxonomic ranks ]
    phy_tree()    Phylogenetic Tree: [ 3423 tips and 3422 internal nodes ]
    
    # PHYLOSEQ OBJECT WITH VARIANCE STABILISING TRANSFORMED OTU TABLE IS CREATED HERE
    ## deseq2 variance stabilisation procedure based on dispersion in the data and size factors
    
    # create phyloseq_to_deseq2 DESeq2 object
    ## make sure that explanatory variables are factors/integers/numerical where needed 
    sample_data(physeq_egg_top80)$exp <- as.factor(sample_data(physeq_egg_top80)$exp)
    sample_data(physeq_egg_top80)$clutch_nr <- as.factor(sample_data(physeq_egg_top80)$clutch_nr)
    
    dds_egg80_compar <- phyloseq_to_deseq2(physeq_egg_top80, ~ exp + clutch_nr)
    dds_egg80_compar
    
    # estimate size factors (to control for library size effects on downstream results)
    dds_egg80_compar <- estimateSizeFactors(dds_egg80_compar)
    # Error in estimateSizeFactorsForMatrix(counts(object), locfunc = locfunc,  : 
    #every gene contains at least one zero, cannot compute log geometric means -->
    
    # calculate geometric means prior to estimate size factors
    gm_mean = function(x, na.rm=TRUE){
      exp(sum(log(x[x > 0]), na.rm=na.rm) / length(x))
    }
    # calculate geometric means
    geoMeans <- apply(counts(dds_egg80_compar), 1, gm_mean)
    
    # estimate Size Factors specifying geoMeans
    dds_egg80_compar <- estimateSizeFactors(dds_egg80_compar, geoMeans=geoMeans)
    sizeFactors(dds_egg80_compar)
    
    # estimate Dispersions specifying geoMeans
    dds_egg80_compar <- estimateDispersions(dds_egg80_compar)
    dispersions(dds_egg80_compar)
    
    # run variance stabilizing transformation (vst) or rlog transformation if size factors vary greatly (FALSE here)
    detach("package:DESeq", unload=TRUE)
    dds_egg80_compar_vst <- varianceStabilizingTransformation(dds_egg80_compar)
    dim(dds_egg80_compar_vst)

    # store original non-transformed otu table in data_pruned_0 and the object to add VST_table in data_pruned_vst
    physeq_egg_top80_noTrans <- physeq_egg_top80
    physeq_egg_top80_vst <- physeq_egg_top80
    otu_table(physeq_egg_top80_noTrans)[20:25,20:25]
    
    # store variance stabilised transformed otu table in soildata_vst
    otu_table(physeq_egg_top80_vst) <- otu_table(assay(dds_egg80_compar_vst), taxa_are_rows = TRUE) 
    otu_table(physeq_egg_top80_vst)[1:5,1:5]
    
    # set negative transformed values to ZERO (as they are estimated to be close to zero based on the fitted NegBin model: the more negative, the more likely to be true 0)
    otu_table(physeq_egg_top80_vst)[otu_table(physeq_egg_top80_vst) < 0] <- 0
    otu_table(physeq_egg_top80_vst)[1:5,1:5]
    
                    # plot dispersion of rarefied raw data SampleType across experimental groups, SampleType * exp
                    ## deseq_var function from http://joey711.github.io/waste-not-supplemental/dispersion-survey/dispersion.html
                    # create interaction factor bioreps
                    is.factor(sample_data(physeq_egg_top80_vst)$exp) #TRUE 
                    sample_data(physeq_egg_top80_vst)$bioreps <- paste0(sample_data(physeq_egg_top80_vst)$exp,"-",sample_data(physeq_egg_top80_vst)$clutch_nr)
                    sample_data(physeq_egg_top80_vst)$bioreps <- as.factor(sample_data(physeq_egg_top80_vst)$bioreps)
                    
                    ## Function for estimating common-scale mean, variance
                    ## We will use this to calculate the common-scale mean/variance for each OTU of each dataset without any data subsampling.
                    deseq_var = function(physeq, bioreps) {
                      require("DESeq")
                      require("plyr")
                      # physeq = GP bioreps = 'BioReps'
                      biorep_levels = levels(factor(get_variable(physeq, bioreps)))
                      ldfs = lapply(biorep_levels, function(L, physeq, bioreps) {
                        # L = biorep_levels[1]
                        whsa = as(get_variable(physeq, bioreps), "character") %in% L
                        # Skip if there are 2 or fewer instances among BioReps Prob don't want to
                        # assume very much from estimates of variance for which N<=2
                        if (sum(whsa) <= 2) {
                          return(NULL)
                        }
                        ps1 = prune_samples(whsa, physeq)
                        # Prune the 'zero' OTUs from this sample set.
                        ps1 = prune_taxa(taxa_sums(ps1) > 5, physeq)
                        # Coerce to matrix, round up to nearest integer just in case
                        x = ceiling(as(otu_table(ps1), "matrix"))
                        # Add 1 to everything to avoid log-0 problems
                        x = x + 1
                        cds = newCountDataSet(countData = x, conditions = get_variable(physeq, 
                                                                                       bioreps))
                        # Estimate Size factors
                        cds = estimateSizeFactors(cds, locfunc = median)
                        # Estimate Dispersions, DESeq
                        cds = estimateDispersions(cds, method = "pooled", sharingMode = "fit-only", 
                                                  fitType = "local")
                        # get the scale-normalized mean and variance
                        df = getBaseMeansAndVariances(counts(cds), sizeFactors(cds))
                        colnames(df) <- c("Mean", "Variance")
                        ## Calculate Mean and Variance for each OTU after rarefying Use a non-random
                        ## definition of 'rarefying'
                        ps1r = transform_sample_counts(ps1, function(x, Smin = min(sample_sums(ps1), 
                                                                                   na.rm = TRUE)) {
                          round(x * Smin/sum(x), digits = 0)
                        })
                        ps1r = prune_taxa(taxa_sums(ps1r) > 5, ps1r)
                        rdf = data.frame(Mean = apply(otu_table(ps1r), 1, mean), Variance = apply(otu_table(ps1r), 
                                                                                                  1, var))
                        # Return results, including cds and 'rarefied' mean-var
                        return(list(df = df, cds = cds, rdf = rdf))
                      }, physeq, bioreps)
                      names(ldfs) <- biorep_levels
                      # Remove the elements that were skipped.
                      ldfs <- ldfs[!sapply(ldfs, is.null)]
                      # Group into data.frames of variance estimates
                      df = ldply(ldfs, function(L) {
                        data.frame(L$df, OTUID = rownames(L$df))
                      })
                      rdf = ldply(ldfs, function(L) {
                        data.frame(L$rdf, OTUID = rownames(L$rdf))
                      })
                      colnames(df)[1] <- bioreps
                      colnames(rdf)[1] <- bioreps
                      # Remove values that are zero for both
                      df <- df[!(df$Mean == 0 & df$Variance == 0), ]
                      rdf <- rdf[!(rdf$Mean == 0 & rdf$Variance == 0), ]
                      # Create a `data.frame` of the DESeq predicted.
                      deseqfitdf = ldply(ldfs, function(x) {
                        df = x$df
                        xg = seq(range(df$Mean)[1], range(df$Mean)[2], length.out = 100)
                        fitVar = xg + fitInfo(x$cds)$dispFun(xg) * xg^2
                        return(data.frame(Mean = xg, Variance = fitVar))
                      })
                      colnames(deseqfitdf)[1] <- bioreps
                      return(list(datadf = df, fitdf = deseqfitdf, raredf = rdf))
                    }


                    ## Define a function for plotting this data.frame
                    plot_dispersion <- function(datadf, fitdf, title = "Microbiome Counts, Common-Scale", 
                                                xbreaks = c(10, 1000, 1e+05)) {
                      require("ggplot2")
                      p = ggplot(datadf, aes(Mean, Variance)) + geom_point(alpha = 0.25, size = 1.5) + 
                        facet_wrap(~BioReps)
                      p = p + scale_y_log10()
                      p = p + scale_x_log10(breaks = xbreaks, labels = xbreaks)
                      p = p + geom_abline(intercept = 0, slope = 1, linetype = 1, size = 0.5, 
                                          color = "gray60")
                      p = p + geom_line(data = fitdf, color = "red", linetype = 1, size = 0.5)
                      p = p + ggtitle(title)
                      return(p)
                    }

                    # Estimate mean-variance relationship
                    deseq_var_egg80 <- deseq_var(physeq_egg_top80_vst, "bioreps")
                    
                    # did not run!
                    pdf("Mean_variance_dispersionEstimation_egg80.pdf", useDingbats = F)
                    plot_dispersion(deseq_var_egg80$datadf, deseq_var_egg80$fitdf)
                    dev.off()


                    
                    
##### Beta diversity analysis using variance-stabilised data #####
                    
physeq_egg_top80_vst

    phyloseq-class experiment-level object
    otu_table()   OTU Table:         [ 3423 taxa and 198 samples ]
    sample_data() Sample Data:       [ 198 samples by 79 sample variables ]
    tax_table()   Taxonomy Table:    [ 3423 taxa by 7 taxonomic ranks ]
    phy_tree()    Phylogenetic Tree: [ 3423 tips and 3422 internal nodes ]
 
# subset experimental groups

  # High diversity soil treatment  
    physeq_egg_top80_vst_Highdiv <- subset_samples(physeq_egg_top80_vst, exp == "control")
    physeq_egg_top80_vst_Highdiv <- prune_taxa(taxa_sums(physeq_egg_top80_vst_Highdiv) > 0, physeq_egg_top80_vst_Highdiv)
    
        otu_table()   OTU Table:         [ 2347 taxa and 90 samples ]
        sample_data() Sample Data:       [ 90 samples by 78 sample variables ]
        tax_table()   Taxonomy Table:    [ 2347 taxa by 7 taxonomic ranks ]
        phy_tree()    Phylogenetic Tree: [ 2347 tips and 2346 internal nodes ]
        
  # Low diversity soil treatment   
    physeq_egg_top80_vst_Lowdiv <- subset_samples(physeq_egg_top80_vst, exp == "treatment")
    physeq_egg_top80_vst_Lowdiv <- prune_taxa(taxa_sums(physeq_egg_top80_vst_Lowdiv) > 0, physeq_egg_top80_vst_Lowdiv)
    
        phyloseq-class experiment-level object
        otu_table()   OTU Table:         [ 1385 taxa and 108 samples ]
        sample_data() Sample Data:       [ 108 samples by 78 sample variables ]
        tax_table()   Taxonomy Table:    [ 1385 taxa by 7 taxonomic ranks ]
        phy_tree()    Phylogenetic Tree: [ 1385 tips and 1384 internal nodes ]
    
# create subsets with complete (noNA) data for immune measures separately
df_physeq_egg_top80_vst_Highdiv <- as.data.frame(sample_data(physeq_egg_top80_vst_Highdiv)@.Data)
colnames(df_physeq_egg_top80_vst_Highdiv) <- sample_data(physeq_egg_top80_vst_Highdiv)@names
df_physeq_egg_top80_vst_Lowdiv <- as.data.frame(sample_data(physeq_egg_top80_vst_Lowdiv)@.Data)
colnames(df_physeq_egg_top80_vst_Lowdiv) <- sample_data(physeq_egg_top80_vst_Lowdiv)@names

physeq_egg_top80_vst_IgYmean_yolk_Highdiv <- subset_samples(physeq_egg_top80_vst_Highdiv, SampleID %in% as.vector(as.character(subset(df_physeq_egg_top80_vst_Highdiv, !is.na(IgYmean_yolk))$SampleID)))  
physeq_egg_top80_vst_IgYmean_yolk_Highdiv <- prune_taxa(taxa_sums(physeq_egg_top80_vst_IgYmean_yolk_Highdiv) > 0 , physeq_egg_top80_vst_IgYmean_yolk_Highdiv)   

    phyloseq-class experiment-level object
    otu_table()   OTU Table:         [ 2089 taxa and 64 samples ]
    sample_data() Sample Data:       [ 64 samples by 78 sample variables ]
    tax_table()   Taxonomy Table:    [ 2089 taxa by 7 taxonomic ranks ]
    phy_tree()    Phylogenetic Tree: [ 2089 tips and 2088 internal nodes ]

physeq_egg_top80_vst_IgYmean_yolk_Lowdiv <- subset_samples(physeq_egg_top80_vst_Lowdiv, SampleID %in% as.vector(as.character(subset(df_physeq_egg_top80_vst_Lowdiv, !is.na(IgYmean_yolk))$SampleID)))  
physeq_egg_top80_vst_IgYmean_yolk_Lowdiv <- prune_taxa(taxa_sums(physeq_egg_top80_vst_IgYmean_yolk_Lowdiv) > 0 , physeq_egg_top80_vst_IgYmean_yolk_Lowdiv)   
    
    phyloseq-class experiment-level object
    otu_table()   OTU Table:         [ 1208 taxa and 74 samples ]
    sample_data() Sample Data:       [ 74 samples by 78 sample variables ]
    tax_table()   Taxonomy Table:    [ 1208 taxa by 7 taxonomic ranks ]
    phy_tree()    Phylogenetic Tree: [ 1208 tips and 1207 internal nodes ]


physeq_egg_top80_vst_lyso_Highdiv <- subset_samples(physeq_egg_top80_vst_Highdiv, SampleID %in% as.vector(as.character(subset(df_physeq_egg_top80_vst_Highdiv, !is.na(lyso))$SampleID)))  
physeq_egg_top80_vst_lyso_Highdiv <- prune_taxa(taxa_sums(physeq_egg_top80_vst_lyso_Highdiv) > 0 , physeq_egg_top80_vst_lyso_Highdiv)   
    
    phyloseq-class experiment-level object
    otu_table()   OTU Table:         [ 1726 taxa and 53 samples ]
    sample_data() Sample Data:       [ 53 samples by 78 sample variables ]
    tax_table()   Taxonomy Table:    [ 1726 taxa by 7 taxonomic ranks ]
    phy_tree()    Phylogenetic Tree: [ 1726 tips and 1725 internal nodes ]

physeq_egg_top80_vst_lyso_Lowdiv <- subset_samples(physeq_egg_top80_vst_Lowdiv, SampleID %in% as.vector(as.character(subset(df_physeq_egg_top80_vst_Lowdiv, !is.na(lyso))$SampleID)))  
physeq_egg_top80_vst_lyso_Lowdiv <- prune_taxa(taxa_sums(physeq_egg_top80_vst_lyso_Lowdiv) > 0 , physeq_egg_top80_vst_lyso_Lowdiv)   
  
    phyloseq-class experiment-level object
    otu_table()   OTU Table:         [ 1193 taxa and 71 samples ]
    sample_data() Sample Data:       [ 71 samples by 78 sample variables ]
    tax_table()   Taxonomy Table:    [ 1193 taxa by 7 taxonomic ranks ]
    phy_tree()    Phylogenetic Tree: [ 1193 tips and 1192 internal nodes ]

    
physeq_egg_top80_vst_ovo_Highdiv <- subset_samples(physeq_egg_top80_vst_Highdiv, SampleID %in% as.vector(as.character(subset(df_physeq_egg_top80_vst_Highdiv, !is.na(ovotransferrin))$SampleID)))  
physeq_egg_top80_vst_ovo_Highdiv <- prune_taxa(taxa_sums(physeq_egg_top80_vst_ovo_Highdiv) > 0 , physeq_egg_top80_vst_ovo_Highdiv)   
    
    otu_table()   OTU Table:         [ 1668 taxa and 46 samples ]
    sample_data() Sample Data:       [ 46 samples by 78 sample variables ]
    tax_table()   Taxonomy Table:    [ 1668 taxa by 7 taxonomic ranks ]
    phy_tree()    Phylogenetic Tree: [ 1668 tips and 1667 internal nodes ]

physeq_egg_top80_vst_ovo_Lowdiv <- subset_samples(physeq_egg_top80_vst_Lowdiv, SampleID %in% as.vector(as.character(subset(df_physeq_egg_top80_vst_Lowdiv, !is.na(ovotransferrin))$SampleID)))  
physeq_egg_top80_vst_ovo_Lowdiv <- prune_taxa(taxa_sums(physeq_egg_top80_vst_ovo_Lowdiv) > 0 , physeq_egg_top80_vst_ovo_Lowdiv)   
    
    phyloseq-class experiment-level object
    otu_table()   OTU Table:         [ 1044 taxa and 61 samples ]
    sample_data() Sample Data:       [ 61 samples by 78 sample variables ]
    tax_table()   Taxonomy Table:    [ 1044 taxa by 7 taxonomic ranks ]
    phy_tree()    Phylogenetic Tree: [ 1044 tips and 1043 internal nodes ]


### Beta diversity analysis on original physeq objects  ###
    # create data frames with metadata
    df_physeq_egg_top80_vst_IgYmean_yolk_Highdiv <- as.data.frame(sample_data(physeq_egg_top80_vst_IgYmean_yolk_Highdiv)@.Data)
    df_physeq_egg_top80_vst_IgYmean_yolk_Lowdiv <- as.data.frame(sample_data(physeq_egg_top80_vst_IgYmean_yolk_Lowdiv)@.Data)
    df_physeq_egg_top80_vst_lyso_Highdiv <- as.data.frame(sample_data(physeq_egg_top80_vst_lyso_Highdiv)@.Data)
    df_physeq_egg_top80_vst_lyso_Lowdiv <- as.data.frame(sample_data(physeq_egg_top80_vst_lyso_Lowdiv)@.Data)
    df_physeq_egg_top80_vst_ovo_Highdiv <- as.data.frame(sample_data(physeq_egg_top80_vst_ovo_Highdiv)@.Data)
    df_physeq_egg_top80_vst_ovo_Lowdiv <- as.data.frame(sample_data(physeq_egg_top80_vst_ovo_Lowdiv)@.Data)
    
    colnames(df_physeq_egg_top80_vst_IgYmean_yolk_Highdiv) <- sample_data(physeq_egg_top80_vst_IgYmean_yolk_Highdiv)@names
    colnames(df_physeq_egg_top80_vst_IgYmean_yolk_Lowdiv) <- sample_data(physeq_egg_top80_vst_IgYmean_yolk_Lowdiv)@names
    colnames(df_physeq_egg_top80_vst_lyso_Highdiv) <- sample_data(physeq_egg_top80_vst_lyso_Highdiv)@names
    colnames(df_physeq_egg_top80_vst_lyso_Lowdiv) <- sample_data(physeq_egg_top80_vst_lyso_Lowdiv)@names
    colnames(df_physeq_egg_top80_vst_ovo_Highdiv) <- sample_data(physeq_egg_top80_vst_ovo_Highdiv)@names
    colnames(df_physeq_egg_top80_vst_ovo_Lowdiv) <- sample_data(physeq_egg_top80_vst_ovo_Lowdiv)@names
    
    ## create distance matrices 
    egg80_vst_wunifr_IgYmean_yolk_Highdiv <- UniFrac(physeq_egg_top80_vst_IgYmean_yolk_Highdiv, weighted = T, normalized = T)
    egg80_vst_uunifr_IgYmean_yolk_Highdiv <- UniFrac(physeq_egg_top80_vst_IgYmean_yolk_Highdiv, weighted = F, normalized = F)
    egg80_vst_wunifr_IgYmean_yolk_Lowdiv <- UniFrac(physeq_egg_top80_vst_IgYmean_yolk_Lowdiv, weighted = T, normalized = T)
    egg80_vst_uunifr_IgYmean_yolk_Lowdiv <- UniFrac(physeq_egg_top80_vst_IgYmean_yolk_Lowdiv, weighted = F, normalized = F)
    
    egg80_vst_wunifr_lyso_Highdiv <- UniFrac(physeq_egg_top80_vst_lyso_Highdiv, weighted = T, normalized = T)
    egg80_vst_uunifr_lyso_Highdiv <- UniFrac(physeq_egg_top80_vst_lyso_Highdiv, weighted = F, normalized = F)
    egg80_vst_wunifr_lyso_Lowdiv <- UniFrac(physeq_egg_top80_vst_lyso_Lowdiv, weighted = T, normalized = T)
    egg80_vst_uunifr_lyso_Lowdiv <- UniFrac(physeq_egg_top80_vst_lyso_Lowdiv, weighted = F, normalized = F)
    
    egg80_vst_wunifr_ovo_Highdiv <- UniFrac(physeq_egg_top80_vst_ovo_Highdiv, weighted = T, normalized = T)
    egg80_vst_uunifr_ovo_Highdiv <- UniFrac(physeq_egg_top80_vst_ovo_Highdiv, weighted = F, normalized = F)
    egg80_vst_wunifr_ovo_Lowdiv <- UniFrac(physeq_egg_top80_vst_ovo_Lowdiv, weighted = T, normalized = T)
    egg80_vst_uunifr_ovo_Lowdiv <- UniFrac(physeq_egg_top80_vst_ovo_Lowdiv, weighted = F, normalized = F)
    
    # create ordinations
    ord_egg80_vst_wunifr_IgYmean_yolk_Highdiv <- ordinate(physeq_egg_top80_vst_IgYmean_yolk_Highdiv, method="PCoA", distance = "wunifrac")
    ord_egg80_vst_uunifr_IgYmean_yolk_Highdiv <- ordinate(physeq_egg_top80_vst_IgYmean_yolk_Highdiv, method="PCoA", distance = "unifrac")
    ord_egg80_vst_wunifr_IgYmean_yolk_Lowdiv <- ordinate(physeq_egg_top80_vst_IgYmean_yolk_Lowdiv, method="PCoA", distance = "wunifrac")
    ord_egg80_vst_uunifr_IgYmean_yolk_Lowdiv <- ordinate(physeq_egg_top80_vst_IgYmean_yolk_Lowdiv, method="PCoA", distance = "unifrac")
    
    ord_egg80_vst_wunifr_lyso_Highdiv <- ordinate(physeq_egg_top80_vst_lyso_Highdiv, method="PCoA", distance = "wunifrac")
    ord_egg80_vst_uunifr_lyso_Highdiv <- ordinate(physeq_egg_top80_vst_lyso_Highdiv, method="PCoA", distance = "unifrac")
    ord_egg80_vst_wunifr_lyso_Lowdiv <- ordinate(physeq_egg_top80_vst_lyso_Lowdiv, method="PCoA", distance = "wunifrac")
    ord_egg80_vst_uunifr_lyso_Lowdiv <- ordinate(physeq_egg_top80_vst_lyso_Lowdiv, method="PCoA", distance = "unifrac")
    
    ord_egg80_vst_wunifr_ovo_Highdiv <- ordinate(physeq_egg_top80_vst_ovo_Highdiv, method="PCoA", distance = "wunifrac")
    ord_egg80_vst_uunifr_ovo_Highdiv <- ordinate(physeq_egg_top80_vst_ovo_Highdiv, method="PCoA", distance = "unifrac")
    ord_egg80_vst_wunifr_ovo_Lowdiv <- ordinate(physeq_egg_top80_vst_ovo_Lowdiv, method="PCoA", distance = "wunifrac")
    ord_egg80_vst_uunifr_ovo_Lowdiv <- ordinate(physeq_egg_top80_vst_ovo_Lowdiv, method="PCoA", distance = "unifrac")
    
      
    
    # adonis IgY
    adonis_egg80_wunifr_IgYmean_yolk_Highdiv  <- adonis(egg80_vst_wunifr_IgYmean_yolk_Highdiv ~ IgYmean_yolk, strata=df_physeq_egg_top80_vst_IgYmean_yolk_Highdiv$room, data = df_physeq_egg_top80_vst_IgYmean_yolk_Highdiv)
    adonis_egg80_uunifr_IgYmean_yolk_Highdiv  <- adonis(egg80_vst_uunifr_IgYmean_yolk_Highdiv ~ IgYmean_yolk, strata=df_physeq_egg_top80_vst_IgYmean_yolk_Highdiv$room, data = df_physeq_egg_top80_vst_IgYmean_yolk_Highdiv)
    adonis_egg80_wunifr_IgYmean_yolk_Lowdiv  <- adonis(egg80_vst_wunifr_IgYmean_yolk_Lowdiv ~ IgYmean_yolk, strata=df_physeq_egg_top80_vst_IgYmean_yolk_Lowdiv$room, data = df_physeq_egg_top80_vst_IgYmean_yolk_Lowdiv)
    adonis_egg80_uunifr_IgYmean_yolk_Lowdiv  <- adonis(egg80_vst_uunifr_IgYmean_yolk_Lowdiv ~ IgYmean_yolk, strata=df_physeq_egg_top80_vst_IgYmean_yolk_Lowdiv$room, data = df_physeq_egg_top80_vst_IgYmean_yolk_Lowdiv)
    
    # adonis lysozyme
    adonis_egg80_wunifr_lyso_Highdiv  <- adonis(egg80_vst_wunifr_lyso_Highdiv ~ lyso, strata=df_physeq_egg_top80_vst_lyso_Highdiv$room, data = df_physeq_egg_top80_vst_lyso_Highdiv)
    adonis_egg80_uunifr_lyso_Highdiv  <- adonis(egg80_vst_uunifr_lyso_Highdiv ~ lyso, strata=df_physeq_egg_top80_vst_lyso_Highdiv$room, data = df_physeq_egg_top80_vst_lyso_Highdiv)
    adonis_egg80_wunifr_lyso_Lowdiv  <- adonis(egg80_vst_wunifr_lyso_Lowdiv ~ lyso, strata=df_physeq_egg_top80_vst_lyso_Lowdiv$room, data = df_physeq_egg_top80_vst_lyso_Lowdiv)
    adonis_egg80_uunifr_lyso_Lowdiv  <- adonis(egg80_vst_uunifr_lyso_Lowdiv ~ lyso, strata=df_physeq_egg_top80_vst_lyso_Lowdiv$room, data = df_physeq_egg_top80_vst_lyso_Lowdiv)
    
    # adonis ovotransferrin
    adonis_egg80_wunifr_ovo_Highdiv  <- adonis(egg80_vst_wunifr_ovo_Highdiv ~ ovotransferrin, strata=df_physeq_egg_top80_vst_ovo_Highdiv$room, data = df_physeq_egg_top80_vst_ovo_Highdiv)
    adonis_egg80_uunifr_ovo_Highdiv  <- adonis(egg80_vst_uunifr_ovo_Highdiv ~ ovotransferrin, strata=df_physeq_egg_top80_vst_ovo_Highdiv$room, data = df_physeq_egg_top80_vst_ovo_Highdiv)
    adonis_egg80_wunifr_ovo_Lowdiv  <- adonis(egg80_vst_wunifr_ovo_Lowdiv ~ ovotransferrin, strata=df_physeq_egg_top80_vst_ovo_Lowdiv$room, data = df_physeq_egg_top80_vst_ovo_Lowdiv)
    adonis_egg80_uunifr_ovo_Lowdiv  <- adonis(egg80_vst_uunifr_ovo_Lowdiv ~ ovotransferrin, strata=df_physeq_egg_top80_vst_ovo_Lowdiv$room, data = df_physeq_egg_top80_vst_ovo_Lowdiv)
    
     
    
    
    pdf("Ordination_egg80_exp_allSamples.pdf", useDingbats = F, width = 6, height = 12)
    
    #wunifrac
    df_Highdiv_wu_yolk <- plot_ordination(physeq_egg_top80_vst_IgYmean_yolk_Highdiv, ord_egg80_vst_wunifr_IgYmean_yolk_Highdiv, justDF=TRUE,axes = c(1,2), color="IgYmean_yolk", type = "Samples", title = "wunifr_IgYmean_yolk_Highdiv" ) 
    df_Lowdiv_wu_yolk <- plot_ordination(physeq_egg_top80_vst_IgYmean_yolk_Lowdiv, ord_egg80_vst_wunifr_IgYmean_yolk_Lowdiv, justDF=TRUE,axes = c(1,2), color="IgYmean_yolk", type = "Samples", title = "wunifr_IgYmean_yolk_Lowdiv" ) 
    
    df_Highdiv_wu_lyso <- plot_ordination(physeq_egg_top80_vst_lyso_Highdiv, ord_egg80_vst_wunifr_lyso_Highdiv,justDF=TRUE, axes = c(1,2), color="lyso", type = "Samples", title = "wunifr_lyso_Highdiv" ) 
    df_Lowdiv_wu_lyso <- plot_ordination(physeq_egg_top80_vst_lyso_Lowdiv, ord_egg80_vst_wunifr_lyso_Lowdiv, justDF=TRUE,axes = c(1,2), color="lyso", type = "Samples", title = "wunifr_lyso_Lowdiv" ) 
    
    df_Highdiv_wu_ovo <- plot_ordination(physeq_egg_top80_vst_ovo_Highdiv, ord_egg80_vst_wunifr_ovo_Highdiv,justDF=TRUE, axes = c(1,2), color="ovotransferrin", type = "Samples", title = "wunifr_ovo_Highdiv" ) 
    df_Lowdiv_wu_ovo <- plot_ordination(physeq_egg_top80_vst_ovo_Lowdiv, ord_egg80_vst_wunifr_ovo_Lowdiv,justDF=TRUE, axes = c(1,2), color="ovotransferrin", type = "Samples", title = "wunifr_ovo_Lowdiv" ) 
    
    # uunifrac
    df_Highdiv_uu_yolk <- plot_ordination(physeq_egg_top80_vst_IgYmean_yolk_Highdiv, ord_egg80_vst_uunifr_IgYmean_yolk_Highdiv, justDF=TRUE,axes = c(1,2), color="IgYmean_yolk", type = "Samples", title = "uunifr_IgYmean_yolk_Highdiv" ) 
    df_Lowdiv_uu_yolk <- plot_ordination(physeq_egg_top80_vst_IgYmean_yolk_Lowdiv, ord_egg80_vst_uunifr_IgYmean_yolk_Lowdiv,justDF=TRUE, axes = c(1,2), color="IgYmean_yolk", type = "Samples", title = "uunifr_IgYmean_yolk_Lowdiv" ) 
    
    df_Highdiv_uu_lyso <- plot_ordination(physeq_egg_top80_vst_lyso_Highdiv, ord_egg80_vst_uunifr_lyso_Highdiv, justDF=TRUE,axes = c(1,2), color="lyso", type = "Samples", title = "uunifr_lyso_Highdiv" ) 
    df_Lowdiv_uu_lyso <- plot_ordination(physeq_egg_top80_vst_lyso_Lowdiv, ord_egg80_vst_uunifr_lyso_Lowdiv,justDF=TRUE, axes = c(1,2), color="lyso", type = "Samples", title = "uunifr_lyso_Lowdiv" ) 
    
    df_Highdiv_uu_ovo <- plot_ordination(physeq_egg_top80_vst_ovo_Highdiv, ord_egg80_vst_uunifr_ovo_Highdiv, justDF=TRUE,axes = c(1,2), color="ovotransferrin", type = "Samples", title = "uunifr_ovo_Highdiv" ) 
    df_Lowdiv_uu_ovo <- plot_ordination(physeq_egg_top80_vst_ovo_Lowdiv, ord_egg80_vst_uunifr_ovo_Lowdiv, justDF=TRUE,axes = c(1,2), color="ovotransferrin", type = "Samples", title = "uunifr_ovo_Lowdiv" ) 

    # (de-)factorize variables
    df_Highdiv_wu_yolk$egg_nr <- as.integer(as.character(df_Highdiv_wu_yolk$egg_nr))
    df_Highdiv_wu_lyso$egg_nr <- as.integer(as.character(df_Highdiv_wu_lyso$egg_nr))
    df_Highdiv_wu_ovo$egg_nr <- as.integer(as.character(df_Highdiv_wu_ovo$egg_nr))
    df_Highdiv_uu_yolk$egg_nr <- as.integer(as.character(df_Highdiv_uu_yolk$egg_nr))
    df_Highdiv_uu_lyso$egg_nr <- as.integer(as.character(df_Highdiv_uu_lyso$egg_nr))
    df_Highdiv_uu_ovo$egg_nr <- as.integer(as.character(df_Highdiv_uu_ovo$egg_nr))
    df_Lowdiv_wu_yolk$egg_nr[c(3,38)] <- c("3", "4")
    df_Lowdiv_wu_yolk$egg_nr <- as.integer(as.character(df_Lowdiv_wu_yolk$egg_nr))
    df_Lowdiv_wu_lyso$egg_nr[c(3,35)] <- c("3", "4")
    df_Lowdiv_wu_lyso$egg_nr <- as.integer(as.character(df_Lowdiv_wu_lyso$egg_nr))
    df_Lowdiv_wu_ovo$egg_nr[c(2,33)] <- c("3", "4")
    df_Lowdiv_wu_ovo$egg_nr <- as.integer(as.character(df_Lowdiv_wu_ovo$egg_nr))
    df_Lowdiv_uu_yolk$egg_nr[c(3,38)] <- c("3", "4")
    df_Lowdiv_uu_yolk$egg_nr <- as.integer(as.character(df_Lowdiv_uu_yolk$egg_nr))
    df_Lowdiv_uu_lyso$egg_nr[c(3,35)] <- c("3", "4")
    df_Lowdiv_uu_lyso$egg_nr <- as.integer(as.character(df_Lowdiv_uu_lyso$egg_nr))
    df_Lowdiv_uu_ovo$egg_nr[c(2,33)] <- c("3", "4")
    df_Lowdiv_uu_ovo$egg_nr <- as.integer(as.character(df_Lowdiv_uu_ovo$egg_nr))
    
    df_Highdiv_wu_yolk$repl <- as.factor(paste0(df_Highdiv_wu_yolk$room, df_Highdiv_wu_yolk$treatment))
    df_Highdiv_wu_lyso$repl <- as.factor(paste0(df_Highdiv_wu_lyso$room, df_Highdiv_wu_lyso$treatment))
    df_Highdiv_wu_ovo$repl <- as.factor(paste0(df_Highdiv_wu_ovo$room, df_Highdiv_wu_ovo$treatment))
    df_Highdiv_uu_yolk$repl <- as.factor(paste0(df_Highdiv_uu_yolk$room, df_Highdiv_uu_yolk$treatment))
    df_Highdiv_uu_lyso$repl <- as.factor(paste0(df_Highdiv_uu_lyso$room, df_Highdiv_uu_lyso$treatment))
    df_Highdiv_uu_ovo$repl <- as.factor(paste0(df_Highdiv_uu_ovo$room, df_Highdiv_uu_ovo$treatment))
    df_Lowdiv_wu_yolk$repl <- as.factor(paste0(df_Lowdiv_wu_yolk$room, df_Lowdiv_wu_yolk$treatment))
    df_Lowdiv_wu_lyso$repl <- as.factor(paste0(df_Lowdiv_wu_lyso$room, df_Lowdiv_wu_lyso$treatment))
    df_Lowdiv_wu_ovo$repl <- as.factor(paste0(df_Lowdiv_wu_ovo$room, df_Lowdiv_wu_ovo$treatment))
    df_Lowdiv_uu_yolk$repl <- as.factor(paste0(df_Lowdiv_uu_yolk$room, df_Lowdiv_uu_yolk$treatment))
    df_Lowdiv_uu_lyso$repl <- as.factor(paste0(df_Lowdiv_uu_lyso$room, df_Lowdiv_uu_lyso$treatment))
    df_Lowdiv_uu_ovo$repl <- as.factor(paste0(df_Lowdiv_uu_ovo$room, df_Lowdiv_uu_ovo$treatment))
    
    df_Highdiv_wu_yolk <- join(df_Highdiv_wu_yolk, Pco_egg_immune[,c(1:5,9)], by = c("exp", "ring_ID", "clutch_nr", "egg_nr"), type = "left")
    df_Highdiv_wu_lyso <- join(df_Highdiv_wu_lyso, Pco_egg_immune[,c(1:5,9)], by = c("exp", "ring_ID", "clutch_nr", "egg_nr"), type = "left")
    df_Highdiv_wu_ovo <- join(df_Highdiv_wu_ovo, Pco_egg_immune[,c(1:5,9)], by = c("exp", "ring_ID", "clutch_nr", "egg_nr"), type = "left")
    df_Highdiv_uu_yolk <- join(df_Highdiv_uu_yolk, Pco_egg_immune[,c(1:5,9)], by = c("exp", "ring_ID", "clutch_nr", "egg_nr"), type = "left")
    df_Highdiv_uu_lyso <-join(df_Highdiv_uu_lyso, Pco_egg_immune[,c(1:5,9)], by = c("exp", "ring_ID", "clutch_nr", "egg_nr"), type = "left")
    df_Highdiv_uu_ovo <- join(df_Highdiv_uu_ovo, Pco_egg_immune[,c(1:5,9)], by = c("exp", "ring_ID", "clutch_nr", "egg_nr"), type = "left")
    df_Lowdiv_wu_yolk <- join(df_Lowdiv_wu_yolk, Pco_egg_immune[,c(1:5,9)], by = c("exp", "ring_ID", "clutch_nr", "egg_nr"), type = "left")
    df_Lowdiv_wu_lyso <- join(df_Lowdiv_wu_lyso, Pco_egg_immune[,c(1:5,9)], by = c("exp", "ring_ID", "clutch_nr", "egg_nr"), type = "left")
    df_Lowdiv_wu_ovo <- join(df_Lowdiv_wu_ovo, Pco_egg_immune[,c(1:5,9)], by = c("exp", "ring_ID", "clutch_nr", "egg_nr"), type = "left")
    df_Lowdiv_uu_yolk <- join(df_Lowdiv_uu_yolk, Pco_egg_immune[,c(1:5,9)], by = c("exp", "ring_ID", "clutch_nr", "egg_nr"), type = "left")
    df_Lowdiv_uu_lyso <- join(df_Lowdiv_uu_lyso, Pco_egg_immune[,c(1:5,9)], by = c("exp", "ring_ID", "clutch_nr", "egg_nr"), type = "left")
    df_Lowdiv_uu_ovo <- join(df_Lowdiv_uu_ovo, Pco_egg_immune[,c(1:5,9)], by = c("exp", "ring_ID", "clutch_nr", "egg_nr"), type = "left")
      
    
    # LMMs egg microbiome versus egg immunity
    
    # highdiv wu
    lmer_Highdiv_wu_yolk <- lmer(IgYmean_yolk ~ Axis.1 + clutch_nr + egg_nr + repl+ (1|ring_ID), data=df_Highdiv_wu_yolk)
    hist(resid(lmer_Highdiv_wu_yolk))
    plot(resid(lmer_Highdiv_wu_yolk)~fitted(lmer_Highdiv_wu_yolk))
    
    anova(lmer_Highdiv_wu_yolk)
    summary(lmer_Highdiv_wu_yolk)  
    
    lmer_Highdiv_wu_lyso <- lmer(log(lyso) ~ Axis.1 + clutch_nr + egg_nr + repl +pH + (1|ring_ID), data=df_Highdiv_wu_lyso)
    hist(resid(lmer_Highdiv_wu_lyso))
    plot(resid(lmer_Highdiv_wu_lyso)~fitted(lmer_Highdiv_wu_lyso))
    
    anova(lmer_Highdiv_wu_lyso)
    summary(lmer_Highdiv_wu_lyso)  
    
    lmer_Highdiv_wu_ovo <- lmer(ovotransferrin ~ Axis.1 + clutch_nr + egg_nr + repl +pH+ (1|ring_ID), data=df_Highdiv_wu_ovo)
    hist(resid(lmer_Highdiv_wu_ovo))
    plot(resid(lmer_Highdiv_wu_ovo)~fitted(lmer_Highdiv_wu_ovo))
    
    anova(lmer_Highdiv_wu_ovo)
    summary(lmer_Highdiv_wu_ovo)  
    
    lmer_Highdiv_wu_PC1 <- lmer(PC1 ~ Axis.1 + clutch_nr + egg_nr + repl +pH+ (1|ring_ID), data=df_Highdiv_wu_ovo)
    hist(resid(lmer_Highdiv_wu_PC1))
    plot(resid(lmer_Highdiv_wu_PC1)~fitted(lmer_Highdiv_wu_PC1))
    
    anova(lmer_Highdiv_wu_PC1)
    summary(lmer_Highdiv_wu_PC1)  
    
    # Lowdiv wu
      lmer_Lowdiv_wu_yolk <- lmer(IgYmean_yolk ~ Axis.1 + clutch_nr + egg_nr + repl+ (1|ring_ID), data=df_Lowdiv_wu_yolk)
    hist(resid(lmer_Lowdiv_wu_yolk))
    plot(resid(lmer_Lowdiv_wu_yolk)~fitted(lmer_Lowdiv_wu_yolk))
    
    anova(lmer_Lowdiv_wu_yolk)
    summary(lmer_Lowdiv_wu_yolk)  
    
    lmer_Lowdiv_wu_lyso <- lmer(log(lyso) ~ Axis.1 + clutch_nr + egg_nr + repl +pH + (1|ring_ID), data=df_Lowdiv_wu_lyso)
    hist(resid(lmer_Lowdiv_wu_lyso))
    plot(resid(lmer_Lowdiv_wu_lyso)~fitted(lmer_Lowdiv_wu_lyso))
    
    anova(lmer_Lowdiv_wu_lyso)
    summary(lmer_Lowdiv_wu_lyso)  
    
    lmer_Lowdiv_wu_ovo <- lmer(ovotransferrin ~ Axis.1 + clutch_nr + egg_nr + repl +pH+ (1|ring_ID), data=df_Lowdiv_wu_ovo)
    hist(resid(lmer_Lowdiv_wu_ovo))
    plot(resid(lmer_Lowdiv_wu_ovo)~fitted(lmer_Lowdiv_wu_ovo))
    
    anova(lmer_Lowdiv_wu_ovo)
    summary(lmer_Lowdiv_wu_ovo)  
    
    lmer_Lowdiv_wu_PC1 <- lmer(PC1 ~ Axis.1 + clutch_nr + egg_nr + repl +pH+ (1|ring_ID), data=df_Lowdiv_wu_ovo)
    hist(resid(lmer_Lowdiv_wu_PC1))
    plot(resid(lmer_Lowdiv_wu_PC1)~fitted(lmer_Lowdiv_wu_PC1))
    
    anova(lmer_Lowdiv_wu_PC1)
    summary(lmer_Lowdiv_wu_PC1)  
    
    
    # highdiv uu
    lmer_Highdiv_uu_yolk <- lmer(IgYmean_yolk ~ Axis.1 + clutch_nr + egg_nr + repl+ (1|ring_ID), data=df_Highdiv_uu_yolk)
    hist(resid(lmer_Highdiv_uu_yolk))
    plot(resid(lmer_Highdiv_uu_yolk)~fitted(lmer_Highdiv_uu_yolk))
    
    anova(lmer_Highdiv_uu_yolk)
    summary(lmer_Highdiv_uu_yolk)  
    
    lmer_Highdiv_uu_lyso <- lmer(log(lyso) ~ Axis.1 + clutch_nr + egg_nr + repl +pH + (1|ring_ID), data=df_Highdiv_uu_lyso)
    hist(resid(lmer_Highdiv_uu_lyso))
    plot(resid(lmer_Highdiv_uu_lyso)~fitted(lmer_Highdiv_uu_lyso))
    
    anova(lmer_Highdiv_uu_lyso)
    summary(lmer_Highdiv_uu_lyso)  
    
    lmer_Highdiv_uu_ovo <- lmer(ovotransferrin ~ Axis.1 + clutch_nr + egg_nr + repl +pH+ (1|ring_ID), data=df_Highdiv_uu_ovo)
    hist(resid(lmer_Highdiv_uu_ovo))
    plot(resid(lmer_Highdiv_uu_ovo)~fitted(lmer_Highdiv_uu_ovo))
    
    anova(lmer_Highdiv_uu_ovo)
    summary(lmer_Highdiv_uu_ovo)  
    
    lmer_Highdiv_uu_PC1 <- lmer(PC1 ~ Axis.1 + clutch_nr + egg_nr + repl +pH+ (1|ring_ID), data=df_Highdiv_uu_ovo)
    hist(resid(lmer_Highdiv_uu_PC1))
    plot(resid(lmer_Highdiv_uu_PC1)~fitted(lmer_Highdiv_uu_PC1))
    
    anova(lmer_Highdiv_uu_PC1)
    summary(lmer_Highdiv_uu_PC1)  
    
    # Lowdiv uu
    lmer_Lowdiv_uu_yolk <- lmer(IgYmean_yolk ~ Axis.1 + clutch_nr + egg_nr + repl+ (1|ring_ID), data=df_Lowdiv_uu_yolk)
    hist(resid(lmer_Lowdiv_uu_yolk))
    plot(resid(lmer_Lowdiv_uu_yolk)~fitted(lmer_Lowdiv_uu_yolk))
    
    anova(lmer_Lowdiv_uu_yolk)
    summary(lmer_Lowdiv_uu_yolk)  
    
    lmer_Lowdiv_uu_lyso <- lmer(log(lyso) ~ Axis.1 + clutch_nr + egg_nr + repl +pH + (1|ring_ID), data=df_Lowdiv_uu_lyso)
    hist(resid(lmer_Lowdiv_uu_lyso))
    plot(resid(lmer_Lowdiv_uu_lyso)~fitted(lmer_Lowdiv_uu_lyso))
    
    anova(lmer_Lowdiv_uu_lyso)
    summary(lmer_Lowdiv_uu_lyso)  
    
    lmer_Lowdiv_uu_ovo <- lmer(ovotransferrin ~ Axis.1 + clutch_nr + egg_nr + repl +pH+ (1|ring_ID), data=df_Lowdiv_uu_ovo)
    hist(resid(lmer_Lowdiv_uu_ovo))
    plot(resid(lmer_Lowdiv_uu_ovo)~fitted(lmer_Lowdiv_uu_ovo))
    
    anova(lmer_Lowdiv_uu_ovo)
    summary(lmer_Lowdiv_uu_ovo) 
    
    lmer_Lowdiv_uu_PC1 <- lmer(PC1 ~ Axis.1 + clutch_nr + egg_nr + repl +pH+ (1|ring_ID), data=df_Lowdiv_uu_ovo)
    hist(resid(lmer_Lowdiv_uu_PC1))
    plot(resid(lmer_Lowdiv_uu_PC1)~fitted(lmer_Lowdiv_uu_PC1))
    
    anova(lmer_Lowdiv_uu_PC1)
    summary(lmer_Lowdiv_uu_PC1)  
    
    # plot
    pdf("Fig_4A_Yolk_IgY_vs_Eggshell_microbiomePCo1.pdf", useDingbats = F, width = 7, height = 6)
    ggplot() +
      geom_point(data = df_Highdiv_wu_yolk, aes(x = Axis.1, y = IgYmean_yolk), colour = "#567c98", shape = 16, size = 2) +
      geom_point(data = df_Highdiv_uu_yolk, aes(x = Axis.1, y = IgYmean_yolk), colour = "#f19534", shape = 16, size = 2) +
      geom_point(data = df_Lowdiv_wu_yolk, aes(x = Axis.1, y = IgYmean_yolk), colour = "#567c98", shape = 2, size = 2) +
      geom_point(data = df_Lowdiv_uu_yolk, aes(x = Axis.1, y = IgYmean_yolk), colour = "#f19534", shape = 2, size = 2) + 
      ggtitle("dot=Highdiv, triangle=lowdiv, orange=uu, marine = wu")
    dev.off()
    
    pdf("Fig_4B_Lysozyme_vs_Eggshell_microbiomePCo1.pdf", useDingbats = F, width = 7, height = 6)
    ggplot() +
      geom_point(data = df_Highdiv_wu_yolk, aes(x = Axis.1, y = log(lyso)), colour = "#567c98", shape = 16, size = 2) +
      geom_point(data = df_Highdiv_uu_yolk, aes(x = Axis.1, y = log(lyso)), colour = "#f19534", shape = 16, size = 2) +
      geom_point(data = df_Lowdiv_wu_yolk, aes(x = Axis.1, y = log(lyso)), colour = "#567c98", shape = 2, size = 2) +
      geom_point(data = df_Lowdiv_uu_yolk, aes(x = Axis.1, y = log(lyso)), colour = "#f19534", shape = 2, size = 2) + 
      ggtitle("dot=Highdiv, triangle=lowdiv, orange=uu, marine = wu")
    dev.off()
    
    pdf("Fig_4C_Ovotransferrin_vs_Eggshell_microbiomePCo1.pdf", useDingbats = F, width = 7, height = 6)
    ggplot() +
      geom_point(data = df_Highdiv_wu_yolk, aes(x = Axis.1, y = ovotransferrin), colour = "#567c98", shape = 16, size = 2) +
      geom_point(data = df_Highdiv_uu_yolk, aes(x = Axis.1, y = ovotransferrin), colour = "#f19534", shape = 16, size = 2) +
      geom_point(data = df_Lowdiv_wu_yolk, aes(x = Axis.1, y = ovotransferrin), colour = "#567c98", shape = 2, size = 2) +
      geom_point(data = df_Lowdiv_uu_yolk, aes(x = Axis.1, y = ovotransferrin), colour = "#f19534", shape = 2, size = 2) + 
      ggtitle("dot=Highdiv, triangle=lowdiv, orange=uu, marine = wu")
    dev.off()
    
    pdf("Fig_4D_PCo1Immune_vs_Eggshell_microbiomePCo1.pdf", useDingbats = F, width = 7, height = 6)
    ggplot() +
      geom_point(data = df_Highdiv_wu_yolk, aes(x = Axis.1, y = PC1), colour = "#567c98", shape = 16, size = 2) +
      geom_point(data = df_Highdiv_uu_yolk, aes(x = Axis.1, y = PC1), colour = "#f19534", shape = 16, size = 2) +
      geom_point(data = df_Lowdiv_wu_yolk, aes(x = Axis.1, y = PC1), colour = "#567c98", shape = 2, size = 2) +
      geom_point(data = df_Lowdiv_uu_yolk, aes(x = Axis.1, y = PC1), colour = "#f19534", shape = 2, size = 2) + 
      ggtitle("dot=Highdiv, triangle=lowdiv, orange=uu, marine = wu")
    dev.off()
        
    
    pdf("Fig_xx_Ordination_egg80_wunifrac_immunity.pdf", useDingbats = F, width = 10, height = 12)
    grid.arrange(a, b, c, d, e, f, nrow = 3, ncol = 2)
    dev.off()
    
    pdf("Fig_xx_Ordination_egg80_uunifrac_immunity1.pdf", useDingbats = F, width = 10, height = 12)
    grid.arrange(g, h, i, j, k, l, nrow = 3, ncol = 2)
    dev.off()
    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    