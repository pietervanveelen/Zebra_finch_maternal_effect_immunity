### This R script belongs to van Veelen et al. The microbial environment modulates non-genetic maternal effects on egg immunity


### With this script path-modelling has been performed. This script was largely developed by G. Sander van Doorn.  

### For questions, contact Pieter van Veelen (pietervanveelen2@gmail.com)


##############################################

### PLS-PM analysis of total data (both experimental groups) without transformation of formative indicators

# clear environment
rm(list = ls(all.names = TRUE)) 

# install packages
#install.packages("plspm", dependencies = T)
#install.packages("plsdepot", dependencies = T)
#install.packages("colortools", dependencies = T)

# load packages
library(plspm)        # partial least squares path modelling
library(plsdepot)			# principal component analysis
library(ggplot2)			# for plotting
library("RColorBrewer")
library(colortools)

# script variables
isMacOS <- TRUE
readClusters <- TRUE
filename <- "all.data.rel.rds"
colA <- 3:283              # columns female microbiome
colB <- c(286:288,290)  	   # columns female immune function indicators
colC <- 292:3714           # columns egg microbiome
colD <- c(3717:3718, 3720) # columns egg immune function indicators
colTr <- 284               # experimental group
clA <- 3
clC <- 3

#### Preliminaries ####

# set working directory
path <-	if(isMacOS) "/Users/pietervanveelen/Google Drive/Rdata backups/CH6_Egg_immunity_zf/CH6_zf_egg_immunity" 
setwd(path)

#### Import data and pre-processing ####

# load data
raw_data <- readRDS(filename)

# discard missing data (listwise deletion)
cols <- sort(c(colA, colTr, colB, colC, colD))
pruned_data <- raw_data[complete.cases(raw_data[,cols]), cols]
n_obs <-  dim(pruned_data)[1]
cat("listwise deletion of missing values:\n  ",dim(raw_data)[1] - n_obs,"\trows eliminated\n  ", n_obs, "\trows remaining\n")
cat("check for remaining NA: ", if(any(is.na(pruned_data))) "fail" else "pass" ,"\n")

# reassign column indices for pruned dataset
indx <- cumsum(c(length(colA), 1, length(colB), length(colC), length(colD)));
colA <- 1 : indx[1];
colTr <- indx[2];
colB <- (indx[2] + 1) : indx[3];
colC <- (indx[3] + 1) : indx[4];
colD <- (indx[4] + 1) : indx[5];

# perform K-means clustering analysis on presence/absence data for female and egg microbiome
flA <- paste("cluster_A_", clA, ".rds", sep = "")
flC <- paste("cluster_C_", clC, ".rds", sep = "")

# transforming relative abundance data into presence/absence data for female (A) and eggshell (C) microbiome data columns
if(readClusters) {
  mapA <- readRDS(flA)
  mapC <- readRDS(flC)
} else {
  df <- t(pruned_data[, colA])
  for(i in 1:dim(df)[1]) {
	  for(j in 1:dim(df)[2]) {
		  df[i, j] <- if(df[i, j] < 1.0e-12) 0 else 1 
	  }
  }

  tryK <- function(n) {
    clus <- kmeans(df[,1:n_obs], n, nstart = 20)
    clus$betweenss / clus$totss
  }
  k <- seq(2:20)
  plot(k, sapply(k,tryK))

  clusterA <- kmeans(df[,1:n_obs], clA, nstart = 100)
  distanceMatrix <- dist(df, method = "manhattan") # distance matrix
  fit <- hclust(distanceMatrix, method="ward.D")
  plot(fit) # display dendogram
  #clusterA <- cutree(fit, k = clA) # cut tree into clusters
  # draw dendogram with red borders around the clusters
  #rect.hclust(fit, k = clA, border="red")
  
  
  mapA <- matrix(0, length(colA), clA)
  for(i in 1:clA) mapA[,i] = sapply(clusterA$cluster, FUN = function(x) { if(x == i) 1 else 0})
  saveRDS(mapA, flA)

  df <- t(pruned_data[, colC])
    for(i in 1:dim(df)[1]) {
	    for(j in 1:dim(df)[2]) {
		    df[i, j] <- if(df[i, j] < 1.0e-12) 0 else 1 
	  }
  }

  #k <- seq(2:40)
  #plot(k, sapply(k,tryK))

  clusterC <- kmeans(df[,1:n_obs], clC, nstart = 100)
  distanceMatrix <- dist(df, method = "manhattan") # distance matrix
  fit <- hclust(distanceMatrix, method="ward.D")
  plot(fit) # display dendogram
  clusterC <- cutree(fit, k = clC) # cut tree into clusters
  # draw dendogram with red borders around the clusters
  rect.hclust(fit, k = clC, border="red")
  
  mapC <- matrix(0, length(colC), clC)
  for(i in 1:clC) mapC[,i] = sapply(clusterC$cluster, FUN = function(x) { if(x == i) 1 else 0})
  saveRDS(mapC, flC)
}

# number of set clusters: clA = clC = 3
# PCA scores of A (female microbiome) and C (egg microbiome)
scoresA = as.matrix(pruned_data[, colA]) %*% mapA
scoresC = as.matrix(pruned_data[, colC]) %*% mapC

#### Principal component analysis ####
pcaA = nipals(scoresA)
pcaA$values
pcaA$loadings
plot(pcaA)

pcaB = nipals(pruned_data[,colB])
pcaB$values
pcaB$loadings
plot(pcaB)

pcaC = nipals(scoresC)
pcaC$values
pcaC$loadings
plot(pcaC)

pcaD = nipals(pruned_data[,colD])
pcaD$values
pcaD$loadings
plot(pcaD)

# rebuild dataset with 
plspm_data <- cbind(pruned_data[,colTr], scoresA, pruned_data[,colB], scoresC, pruned_data[,colD])
indx <- cumsum(c(1, clA, length(colB), clC, length(colD)));
colA <- (indx[1] + 1) : indx[2];
colB <- (indx[2] + 1) : indx[3];
colC <- (indx[3] + 1) : indx[4];
colD <- (indx[4] + 1) : indx[5];
colnames(plspm_data)[1] <- "treatment"
colname <- function(lb, i) paste(lb, i , sep ="")
colnames(plspm_data)[colA] <- mapply(colname, "cl.f.", seq(1:clA))
colnames(plspm_data)[colC] <- mapply(colname, "cl.e.", seq(1:clC))

# add noise - to avoid singular data matrix
plspm_data[,colA] <- plspm_data[,colA] + rnorm(n_obs, mean = 0, sd = 0.0001)
plspm_data[,colC] <- plspm_data[,colC] + rnorm(n_obs, mean = 0, sd = 0.0001)

# based on previous PCA plots:
# re-adjust direction of female and egg microbiome cl2, cl3 and egg cl2, f_hapt (to obtain most positive associations)
colnames(plspm_data)
#plspm_data$Ncl.f.2 <- -1 * plspm_data$cl.f.2
#plspm_data$Ncl.f.3 <- -1 * plspm_data$cl.f.3
#plspm_data$Ncl.e.2 <- -1 * plspm_data$cl.e.2
plspm_data$Nf_haptoglobin <- -1 * plspm_data$f_haptoglobin

#redefine data blocks using changed-direction data

#colA <- 3:283              # columns female microbiome
#colB <- c(286:288,290)  	  # columns female immune function indicators
#colC <- 292:3714           # columns egg microbiome
#colD <- c(3717:3718, 3720) # columns egg immune function indicators
#colTr <- 284               # experimental group
colnames(plspm_data)

colA = plspm_data[,c(2,3,4)]
colB = plspm_data[,c(5,6,7,15)]
colC = plspm_data[,c(9,10,11)]
colD = plspm_data[,c(12,13,14)]
colTr = plspm_data[,1]

new_plspm_data = cbind(colTr, colA, colB, colC, colD)
names(new_plspm_data)[1] <- "treatment"

#### Principal component analysis ####
pcaA = nipals(colA)
pcaA$values
pcaA$loadings
plot(pcaA)  # roughly similar direction of female microbiome clusters after directional adjustment

pcaB = nipals(colB)
pcaB$values
pcaB$loadings
plot(pcaB)  # Nf_haptoglobin and f_IgY_plasma as immune index cluster after directional adjustment
            # f_agglutination and residual mass should be treated separately outside immune index block

pcaC = nipals(colC)
pcaC$values
pcaC$loadings
plot(pcaC)  # Egg microbiome clusters are orthogonal, and cannot be transformed properly
            # keep clusters (neg Cl2) as formative indicators to egg microbiome latent variable 

pcaD = nipals(colD)
pcaD$values
pcaD$loadings
plot(pcaD)  # Egg immune parameters are orthogonal, and cannot be transformed properly
            # egg lysozyme, IgY and pH should be treated separately outside immune index block


# create new indexes
indx <- cumsum(c(1, clA, length(colB), clC, length(colD)));
colA <- (indx[1] + 1) : indx[2];
colB <- (indx[2] + 1) : indx[3];
colC <- (indx[3] + 1) : indx[4];
colD <- (indx[4] + 1) : indx[5];


# define associations between manifest and latent variables
# [colA  female microbiome; colB female immune function; colC egg microbiome; colD egg immune function]

# model with microbiome blocks, female body mass as separate block, egg immunity as single block
# definition of inner model
fem_resid_mass  = c(0, 0, 0, 0, 0, 0, 0, 0, 0)
fem_microbiom   = c(1, 0, 0, 0, 0, 0, 0, 0, 0)
fem_IgY         = c(1, 1, 0, 0, 0, 0, 0, 0, 0)
fem_agg_titre   = c(1, 1, 0, 0, 0, 0, 0, 0, 0)
fem_haptoglobin = c(1, 1, 0, 0, 0, 0, 0, 0, 0)
egg_microbiom   = c(0, 1, 0, 0, 0, 0, 0, 0, 0)
egg_IgY         = c(1, 0, 1, 1, 1, 1, 0, 0, 0)
egg_pH          = c(1, 0, 1, 1, 1, 1, 0, 0, 0)
egg_lysozyme    = c(1, 0, 1, 1, 1, 1, 0, 1, 0)
my_paths = rbind(fem_resid_mass, fem_microbiom, fem_IgY, fem_agg_titre,
                 fem_haptoglobin, egg_microbiom, egg_IgY, egg_pH, egg_lysozyme)
colnames(my_paths) = rownames(my_paths)


## pasted back here to check on indexes and parameters for blocking
#colA <- 3:283              # columns female microbiome
#colB <- c(286:288,290)  	  # columns female immune function indicators
#colC <- 292:3714           # columns egg microbiome
#colD <- c(3717:3718, 3720) # columns egg immune function indicators
#colTr <- 284               # experimental group
colnames(new_plspm_data)

# redefine columns for new_plspm_data
colA = new_plspm_data[,c(2,3,4)]
colB = new_plspm_data[,c(5,6,7,8)]
colC = new_plspm_data[,c(9,10,11)]
colD = new_plspm_data[,c(12,13,14)]
colTr = new_plspm_data[,1]

indx <- cumsum(c(1, clA, length(colB), clC, length(colD)));
colA <- (indx[1] + 1) : indx[2];
colB <- (indx[2] + 1) : indx[3];
colC <- (indx[3] + 1) : indx[4];
colD <- (indx[4] + 1) : indx[5];
colnames(new_plspm_data)[1] <- "treatment"


## because of potential negative correlations and new blocks, redefine model with different blocks including 
# f_resid_mass (A), 
# f_microbiome (B),
# f_agg_titre (A), 
# [f_haptoglobin + f_IgY_plasma] (A),
# e_microbiome (B),
# e_IgY_yolk (A), 
# e_pH (A), 
# e_lysozyme (A), 
my_blocks = list(colB[1], colA, colB[2], colB[c(3,4)], colC, colD[1], colD[3], colD[2])
my_modes = c("A", "B", "A", "A", "B", "A", "A", "A")


## redefine inner model using new blocks
# model with: 
#   female body mass as separate block, 
#   female microbiome block, 
#   female immunity as two blocks (lysozyme out because of ~no variance)
#   egg microbiome as a single block, 
#   egg immunity three separate blocks

# definition of inner model
fem_resid_mass  = c(0, 0, 0, 0, 0, 0, 0, 0)
fem_microbiom   = c(1, 0, 0, 0, 0, 0, 0, 0)
fem_aggl        = c(1, 1, 0, 0, 0, 0, 0, 0)
fem_immunity    = c(1, 1, 0, 0, 0, 0, 0, 0)
egg_microbiom   = c(0, 1, 0, 0, 0, 0, 0, 0)
egg_IgY         = c(0, 0, 1, 1, 1, 0, 0, 0)
egg_pH          = c(0, 0, 1, 1, 1, 0, 0, 0)
egg_lysozyme    = c(0, 0, 1, 1, 1, 0, 1, 0)
my_paths = rbind(fem_resid_mass, fem_microbiom, fem_aggl, fem_immunity, egg_microbiom, egg_IgY, egg_pH, egg_lysozyme)
colnames(my_paths) = rownames(my_paths)

# visualise inner model
my_paths
pdf("Inner_model_PLSPM.pdf", useDingbats = F)
innerplot(my_paths)
dev.off()


### run full model ###

# run partial least squares path model analysis
my_model = plspm(new_plspm_data, my_paths, my_blocks, modes = my_modes, maxiter = 5000, boot.val = TRUE, br = 1000)


# summary output
#summary(my_model)
my_model$gof

# visualise inner model
path_coefs = my_model$path_coefs
innerplot(my_model)

pdf("PLS_PM_globalModel_noTransfFormatives_linesWeighted.pdf", useDingbats = F, width = 8, height = 8)
plot(my_model, what = "inner", arr.lwd = 10 * abs(round(path_coefs, 2)))
dev.off()

# visualise weights and loadings
my_model$outer_model
plot(my_model, what = "loadings")
plot(my_model, what = "weights")
#??plot.plspm


# plot model
plot(my_model, box.size = 0.10)

# GOF
my_model$gof
0.2375498

# summary plspm
my_model$inner_summary
summary(my_model)


# check unidimensionality of models
my_model$unidim

# plot inner model metrics
#plot(my_model_hi, what = "weights")
#plot(my_model_lo, what = "loadings")

# compare experimental groups
my_model_boot = plspm.groups(my_model, new_plspm_data$treatment, method = "bootstrap", reps = 1000)
my_model_boot
plot(my_model)


#compare global path coefficients with my_model summary
summary(my_model)

# inner model low
my_model_boot$group1

#padjust FDR q
# global model and boot test for TrtEff 
tests_my_model_boot <- as.data.frame(my_model_boot$test)
tests_my_model_boot$FDRq <- p.adjust(tests_my_model_boot$p.value, method = "BH")
tests_my_model_boot$sig.q.01 <- ifelse(tests_my_model_boot$FDRq < 0.1, "yes", "no")
tests_my_model_boot

# coefs and SE for HighDiv
tests_my_model_boot_high <- my_model
tests_my_model_boot_high$FDRq <- p.adjust(tests_my_model_boot_high$p.value, method = "BH")
tests_my_model_boot_high$sig.q.01 <- ifelse(tests_my_model_boot_high$FDRq < 0.1, "yes", "no")
tests_my_model_boot_high

tests_my_model_boot <- as.data.frame(my_model_boot$test)
tests_my_model_boot$FDRq <- p.adjust(tests_my_model_boot$p.value, method = "BH")
tests_my_model_boot$sig.q.01 <- ifelse(tests_my_model_boot$FDRq < 0.1, "yes", "no")
tests_my_model_boot
# write output table statistics and coefficients from TrtEff bootstrap t-test
capture.output(tests_my_model_boot, file = "Final_Path_coeff_my_model_noTransfFormative_boot_trtEff.txt")

# write output table statistics and coefficients model summary including all coeffs of global model
capture.output(summary(my_model), file =  "Final_PLSPM_my_model_noTransfFormative.txt")


# plot model
plot(my_model)
pdf("PLS_PM_globalModel_noTransfFormatives.pdf", useDingbats = F, width = 8, height = 8)
plot(my_model, what = "inner", arr.lwd = 10 * abs(round(path_coefs, 2)))
dev.off()

# plot outer model
pdf("PLS_PM_outerModel.pdf", useDingbats = F, width = 8, height = 8)
plot(my_model, "outer")
dev.off()
#### by treatment ####


# reformat output for group 1 (high div) and group 2 (low div)

out <- my_model_boot$test[,2:3]
out$SE.high <- c(rep("NA", 16))
out$SE.low <- c(rep("NA", 16))
# high div coef se
# fill in SE values from group-specific model outputs
out$SE.high[1] <- my_model_boot$group1$fem_microbiom[2,2]
out$SE.high[2] <- my_model_boot$group1$fem_aggl[2,2]
out$SE.high[3] <- my_model_boot$group1$fem_immunity[2,2]
out$SE.high[4] <- my_model_boot$group1$fem_aggl[3,2]
out$SE.high[5] <- my_model_boot$group1$fem_immunity[3,2]
out$SE.high[6] <- my_model_boot$group1$egg_microbiom[2,2]
out$SE.high[7] <- my_model_boot$group1$egg_IgY[2,2]
out$SE.high[8] <- my_model_boot$group1$egg_pH[2,2]
out$SE.high[9] <- my_model_boot$group1$egg_lysozyme[2,2]
out$SE.high[10] <- my_model_boot$group1$egg_IgY[3,2]
out$SE.high[11] <- my_model_boot$group1$egg_pH[3,2]
out$SE.high[12] <- my_model_boot$group1$egg_lysozyme[3,2]
out$SE.high[13] <- my_model_boot$group1$egg_IgY[4,2]
out$SE.high[14] <- my_model_boot$group1$egg_pH[4,2]
out$SE.high[15] <- my_model_boot$group1$egg_lysozyme[4,2]
out$SE.high[16] <- my_model_boot$group1$egg_lysozyme[5,2]

# round to 4 decimals
out$SE.high <- round(as.numeric(as.character(out$SE.high)), 4)

# low div coef se

# fill in SE values from group-specific model outputs
out$SE.low[1] <- my_model_boot$group2$fem_microbiom[2,2]
out$SE.low[2] <- my_model_boot$group2$fem_aggl[2,2]
out$SE.low[3] <- my_model_boot$group2$fem_immunity[2,2]
out$SE.low[4] <- my_model_boot$group2$fem_aggl[3,2]
out$SE.low[5] <- my_model_boot$group2$fem_immunity[3,2]
out$SE.low[6] <- my_model_boot$group2$egg_microbiom[2,2]
out$SE.low[7] <- my_model_boot$group2$egg_IgY[2,2]
out$SE.low[8] <- my_model_boot$group2$egg_pH[2,2]
out$SE.low[9] <- my_model_boot$group2$egg_lysozyme[2,2]
out$SE.low[10] <- my_model_boot$group2$egg_IgY[3,2]
out$SE.low[11] <- my_model_boot$group2$egg_pH[3,2]
out$SE.low[12] <- my_model_boot$group2$egg_lysozyme[3,2]
out$SE.low[13] <- my_model_boot$group2$egg_IgY[4,2]
out$SE.low[14] <- my_model_boot$group2$egg_pH[4,2]
out$SE.low[15] <- my_model_boot$group2$egg_lysozyme[4,2]
out$SE.low[16] <- my_model_boot$group2$egg_lysozyme[5,2]

# round to 4 decimals
out$SE.low <- round(as.numeric(as.character(out$SE.low)), 4)

out$comp = rownames(out)

library(reshape2)
out.long <- reshape(out, varying = c(1:4), direction = "long", idvar = "comp")
names(out.long) <- c("paths", "exp", "coef", "SE")

# save treatment-specific path coefficient estimates extracted from full model
capture.output(out.long, file = "Groupwise_path_coeffsSE_ExpEff_bootstrapTtest_noTransfFormatives_my_model_boot.txt")

# save treatment-specific path coefficient statistics extracted from full model
capture.output(my_model_boot$group1, file = "HighDiv_path_coeffsSE_ExpEff_bootstrapTtest_noTransfFormatives_my_model_boot.txt")
capture.output(my_model_boot$group2, file = "LowDiv_path_coeffsSE_ExpEff_bootstrapTtest_noTransfFormatives_my_model_boot.txt")


pdf("Final_path_coeffsSE_ExpEff_bootstrapTtest_noTransfFormatives_my_model.pdf", useDingbats = F, width = 7, height = 6)
ggplot(data = out.long, aes(x = paths, y = coef, group = exp, color = exp)) +
  geom_point(aes(shape = exp), position = position_dodge(0.25), size = 2) +
  geom_errorbar(aes(ymin = coef-SE, ymax = coef+SE), width = 0, position = position_dodge(0.25)) +
  coord_flip() +
  theme_bw() + 
  scale_color_manual(values = c("#FEB24C","#74A9CF")) 
dev.off()  



# path coefficients between female and male students
pdf("Final_path_coeffs_ExpEff_bootstrapTtest_noTransfFormatives_my_model.pdf", useDingbats = F, width = 7, height = 6)
barplot(t(as.matrix(my_model_boot$test[,2:3])), border = NA, beside = TRUE,
        col = c("#FEB24C","#74A9CF"), las = 2, ylim = c(-1, 1),
        cex.names = 0.8, col.axis = "gray30", cex.axis = 0.8)
# add horizontal line
abline(h = 0, col = "gray50")
# add itle
title("Path coefficients of Birds on High and Low diversity environments",
      cex.main = 0.95, col.main = "gray30")
# add legend
legend("top", legend = c("high", "low"), pt.bg = c("#FEB24C", "#A6BDDB"),
       ncol = 2, pch = 22, col = c("#FEB24C", "#74A9CF"), bty = "n",
       text.col = "gray40")
dev.off()





#### split analysis according to treatment ####

## run separate models (but identical models to total dataset) for both treatment groups
plspm_data_lo = new_plspm_data[new_plspm_data$treatment == "low", ]
plspm_data_hi = new_plspm_data[new_plspm_data$treatment == "high", ]

# define separate models for subset data sets
my_model_lo = plspm(plspm_data_lo, my_paths, my_blocks, modes = my_modes, maxiter = 5000, boot.val = TRUE)
my_model_hi = plspm(plspm_data_hi, my_paths, my_blocks, modes = my_modes, maxiter = 5000, boot.val = TRUE)

summary(my_model_lo)
summary(my_model_hi)
my_model_lo$gof
my_model_hi$gof

plot(my_model_lo, box.size = 0.14)
plot(my_model_hi, box.size = 0.14)

plot(my_model_lo, what = "weights")
plot(my_model_hi, what = "weights")

plot(my_model_lo, what = "loadings")
plot(my_model_hi, what = "loadings")

# check unidimensionality of models
my_model_lo$unidim
my_model_hi$unidim



###