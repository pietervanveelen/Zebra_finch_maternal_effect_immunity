### This R script belongs to van Veelen et al. The microbial environment modulates non-genetic maternal effects on egg immunity


### With this script raw 16S rRNA gene sequence data in fastq format have been preprocessed to a phyloseq object. 
### For questions, contact Pieter van Veelen (pietervanveelen2@gmail.com)


##############################################

### Processing of sequence data using DADA2 ###

# Following Callahan et al 2016. Nat Meth (http://www.nature.com.proxy-ub.rug.nl/articles/nmeth.3869.pdf)


source("https://bioconductor.org/biocLite.R")
biocLite("dada2")

library(dada2)
packageVersion("dada2") #1.9.3

library("knitr")

biocLite("devtools")
library("devtools")
devtools::install_github("benjjneb/dada2")

source("http://bioconductor.org/biocLite.R")
biocLite("GenomeInfoDbData")

# Dada2 denoising
### https://benjjneb.github.io/dada2/tutorial.html ###

path <- "~/6314A-q2_analysis/All_sample-wise_fastqgz/6314A_only_sampleWise_fastgz"
list.files(path)

# Forward and reverse fastq filenames have format: SAMPLENAME_R1_001.fastq and SAMPLENAME_R2_001.fastq
fnFs <- sort(list.files(path, pattern="_L001_R1_001.fastq", full.names = TRUE))
fnRs <- sort(list.files(path, pattern="_L001_R2_001.fastq", full.names = TRUE))

# Extract sample names, assuming filenames have format: SAMPLENAME_XXX.fastq
sample.names <- sapply(strsplit(basename(fnFs), "_"), `[`, 1)

# check quality plots (here Forward read of first two samples)
plotQualityProfile(fnFs[1:2])

### perform filtering and trimming ###

# path to store filtered reads
filt_path <- file.path(path, "filtered") # Place filtered files in filtered/ subdirectory
# file name extensions for filtered reads
filtFs <- file.path(filt_path, paste0(sample.names, "_F_filt.fastq.gz"))
filtRs <- file.path(filt_path, paste0(sample.names, "_R_filt.fastq.gz"))

## We’ll use standard filtering parameters: maxN=0 (DADA2 requires no Ns), truncQ=2, rm.phix=TRUE and maxEE=2. The maxEE parameter sets the maximum number of “expected errors” allowed in a read, which is a better filter than simply averaging quality scores.
# Filter the forward and reverse reads

out <- filterAndTrim(fnFs, filtFs, fnRs, filtRs, truncLen=c(240,200),
                     maxN=0, maxEE=c(2,5), truncQ=2, rm.phix=TRUE,
                     compress=TRUE, multithread=TRUE)

# Some input samples had no reads pass the filter.
head(out)
str(out)

# if samples drop out because of retaining no reads that pass the filter and/or trimming (mostly low coverage samples), run:
exists <- file.exists(filtFs) & file.exists(filtRs)
filtFs <- filtFs[exists]
filtRs <- filtRs[exists]

# learn errror rates for forward and reverse reads separately
errF <- learnErrors(filtFs, multithread=TRUE)
errR <- learnErrors(filtRs, multithread=TRUE)

# It is always worthwhile, as a sanity check if nothing else, to visualize the estimated error rates:
plotErrors(errF, nominalQ=TRUE)
plotErrors(errR, nominalQ=TRUE)
  ## seem reasonably fitting the predictions


### DEREPLICATION ###


### !!! when many samples (total space >= RAM X Gb), use BIG DATA WORKFLOW FOR PAIRED_END READS ####
## https://benjjneb.github.io/dada2/bigdata_paired.html
## start here from "Infer Sequence Variants" From "MERGERS <- "
# Sample inference and merger of paired-end reads


#mergers <- vector("list", length(sample.names))
#names(mergers) <- sample.names
#for(sam in sample.names) {
#  cat("Processing:", sam, "\n")
#  derepF <- derepFastq(filtFs[[sam]])
#  ddF <- dada(derepF, err=errF, multithread=TRUE)
#  derepR <- derepFastq(filtRs[[sam]])
#  ddR <- dada(derepR, err=errR, multithread=TRUE)
#  merger <- mergePairs(ddF, derepF, ddR, derepR)
#  mergers[[sam]] <- merger
#}
#rm(derepF); rm(derepR)

# Construct sequence table and remove chimeras
#seqtab <- makeSequenceTable(mergers)
#saveRDS(seqtab, "/path/to/run1/output/seqtab.rds") # CHANGE ME to where you want sequence table saved
## This portion of the workflow should be performed on a run-by-run basis, as error rates can differ between runs.


# Dereplicate the filtered fastq files
derepFs <- derepFastq(filtFs, verbose=TRUE)
derepRs <- derepFastq(filtRs, verbose=TRUE)

# Name the derep-class objects by the sample names
names(derepFs) <- sample.names
names(derepRs) <- sample.names

### SAMPLE INFERENCE ###

## We are now ready to apply the core sequence-variant inference algorithm to the dereplicated data.
# Infer the sequence variants in each sample
dadaFs <- dada(derepFs, err=errF, multithread=TRUE)
dadaRs <- dada(derepRs, err=errR, multithread=TRUE)

# check for example sample 1 for its forward reads and see how many unique are retained after denoising
dadaFs[[1]]



### Merge paired reads ###
## Spurious sequence variants are further reduced by merging overlapping reads. The core function here is mergePairs, 
## which depends on the forward and reverse reads being in matching order at the time they were dereplicated.
# Merge the denoised forward and reverse reads:
mergers <- mergePairs(dadaFs, derepFs, dadaRs, derepRs, verbose=TRUE)
# Inspect the merger data.frame from the first sample
head(mergers[[1]])



### Construct sequence table ###
## We can now construct a sequence table of our mouse samples, a higher-resolution version of the OTU table 
## produced by traditional methods.
seqtab <- makeSequenceTable(mergers)
dim(seqtab)

# Inspect distribution of sequence lengths
table(nchar(getSequences(seqtab)))
hist(nchar(getSequences(seqtab)), main="Distribution of sequence lengths")

## Peak of distribution falls nicely as expected peaking at 374 (cf. analysis based on QIIME1 uclust method CH3_van Veelen et al., in prep.)
# remove sequences <364 & >384 bp to remove non-specific reads (e.g. 12S Zebra Finch)
seqtab2 <- seqtab[,nchar(colnames(seqtab)) %in% seq(364,384)]


### Remove chimeras ###
## The core dada method removes substitution and indel errors, but chimeras remain. Fortunately, the accuracy of 
## the sequences after denoising makes identifying chimeras simpler than it is when dealing with fuzzy OTUs: 
## all sequences which can be exactly reconstructed as a bimera (two-parent chimera) from more abundant sequences.
# Remove chimeric sequences:
seqtab.nochim <- removeBimeraDenovo(seqtab2, method="consensus", multithread=TRUE, verbose=TRUE)
dim(seqtab.nochim)
  ## Identified 1158 bimeras out of 11006 input sequences.

sum(seqtab.nochim)/sum(seqtab2)
[1] 0.9927108 # (~0.08% chimeras)


### Track reads through the pipeline ###
## As a final check of our progress, we’ll look at the number of reads that made it through each step in the 
## pipeline:
getN <- function(x) sum(getUniques(x))
track <- cbind(out, sapply(dadaFs, getN), sapply(mergers, getN), rowSums(seqtab2), rowSums(seqtab.nochim))
# If processing a single sample, remove the sapply calls: e.g. replace sapply(dadaFs, getN) with getN(dadaFs)
colnames(track) <- c("input", "filtered", "denoised", "merged", "tabled", "nonchim")
rownames(track) <- sample.names
head(track)
  ## looks reasonable. In some samples quite a few reads lost, but in others not. Egg samples are low in DNA content
  ## and may have yielded lower quality DNA


### Assign taxonomy ### 
## based on RDP classifier with Naive Bayesian algorithm:
## https://www.ncbi.nlm.nih.gov/pubmed/17586664
# classification based on RDP reference data  (trainset 16)
taxa_RDP <- assignTaxonomy(seqtab.nochim, "Training/rdp_train_set_16.fa.gz", multithread=TRUE)
taxa_RDP <- addSpecies(taxa_RDP, "Training/rdp_species_assignment_16.fa.gz")

# classification based on Silva reference data  (release 132)
taxa_Silva132 <- assignTaxonomy(seqtab.nochim, "Training/silva_nr_v132_train_set.fa.gz", multithread=TRUE)
taxa_Silva132 <- addSpecies(taxa, "Training/silva_species_assignment_v132.fa.gz")

  # View sumary of taxonomic assignments
  taxa.print_RDP <- taxa_RDP # Removing sequence rownames for display only
  rownames(taxa.print_RDP) <- NULL
  head(taxa.print_RDP)
  
  taxa.print_Silva132 <- taxa_Silva132 # Removing sequence rownames for display only
  rownames(taxa.print_Silva132) <- NULL
  head(taxa.print_Silva132)

### save files to use in Phyloseq ###
  
  # Write to disk
  saveRDS(seqtab.nochim, "/Users/pietervanveelen/6314A-q2_analysis/6314A_seqtab_final.rds") 
  saveRDS(taxa_RDP, "/Users/pietervanveelen/6314A-q2_analysis/6314A_RDP_tax_final.rds") 

  seqtab.nochim <- readRDS("6314A_seqtab_final.rds")
  taxa_RDP <- readRDS("6314A_RDP_tax_final.rds")
  
  write.table(t(seqtab.nochim), "seqtab-nochim.txt", sep="\t", row.names=TRUE, col.names=NA, quote=FALSE)
  uniquesToFasta(seqtab.nochim, fout='rep-seqs.fna', ids=colnames(seqtab.nochim))
  
  # concatenate mapping files
  map_run1 <- read.table("Mappingfile_ZF_6314A_R1.tsv",sep = "\t",dec = ".", header = T )
  map_run2 <- read.table("Mappingfile_ZF_6314A_R2.tsv",sep = "\t",dec = ".", header = T )
  map_all <- rbind(map_run1, map_run2)
  map_6314 <- subset(map_all, Study == "6314A" | Study == "NC1" | Study == "NC8")
  nrow(map_6314) # 573
  
  # final mapping file
  write.table(map_6314, sep = "\t", dec = ".", file = "Mapping_file_nometadata_20180306.txt")
  
  
  
  
### create phyloseq object ###

library(phyloseq)
  
# open 6314A_RDP_tax_final.rds
  write.table(taxa_RDP, sep = "\t", dec = ".", file = "tax_table_dada2_RDP_R.txt")
  tax_table_RDP <- taxa_RDP
  
  map <- as.data.frame(read.table("Mapping_file_nometadata_20180306.txt", sep="\t", dec = "."))
  rep_seqs <- readDNAStringSet("qza_to_physeq/aligned-seqs/aligned-dna-sequences.fasta", format="fasta",
                               nrec=-1L, skip=0L, seek.first.rec=FALSE, use.names=TRUE)
 
  biom_tax <- import_biom("qza_to_physeq/exported-table/otu_table_taxAdded.biom", parseFunction = parse_taxonomy_default)
  
  library(ape)
  tree <- read_tree("qza_to_physeq/exported-tree/tree.nwk")
  is.rooted(tree)
  
  # create aspects of physeq object
  mapping <- import_qiime_sample_data("Mapping_file_nometadata_20180306.txt")
  features <- otu_table(biom_tax)
  ASV_table <- tax_table(biom_tax)
  phy_tree <- phy_tree(tree)
  
  # create phyloseq object
  psdata <- merge_phyloseq(mapping,features,ASV_table, phy_tree)
  
  # change taxa names (feature names to "ASV_#")
  ASV_names <- as.data.frame(sprintf("ASV_%d", 1:9848))
  colnames(ASV_names)[1] <- "ASV_NAMES"
  ASV_names$TAX_NAMES <- taxa_names(psdata)
  ASV_names$sequence <- taxa_names(psdata)
  
    # to align ASV names with sequence names in tax_table
    check_tax <-data.frame(tax_table(biom_tax)@.Data)
    check_tax$sequence <- rownames(check_tax)
    
    merged_ASV_taxtable <- join(ASV_names, check_tax, by = "sequence", type = "inner")
    rownames(merged_ASV_taxtable) <- merged_ASV_taxtable$ASV_NAMES
  
  # replace taxa_names in physeq object
  taxa_names(psdata) <- merged_ASV_taxtable$ASV_NAMES
  
  ### resolve phylogenetic tree ###
  library(ape)
  # evaluate tree topology
  is.binary.tree(phy_tree(psdata)) # FALSE --> polychotomy present (node has more than 2 tips)
  
  # resolve single polychotomous node
  phy_tree_resolved <- multi2di(phy_tree(psdata))
  is.binary.tree(phy_tree_resolved)
  # create new phy_tree
  tree2 <- phy_tree_resolved
  
  # merge new phy_tree object with sample_data and otu_table into new phyloseq object
  psdata_ResTree <- merge_phyloseq(otu_table(psdata), sample_data(psdata), tax_table(psdata), tree2)
  
  # Name taxonomic ranks
  
  rank_names(psdata_ResTree)
  colnames(tax_table(psdata_ResTree)) <- c(k = "Kingdom", p = "Phylum", c = "Class", o = "Order", f = "Family", g = "Genus", s = "Species")
  
  ### remove Archaea, Chloroplast and Mitochondia and unassigned Kingdom
  psdata_unfiltered <- psdata_ResTree
  physeq1 <- subset_taxa(psdata_ResTree, Kingdom == "Bacteria") # dropped 159 ASVs
  physeq2 <- subset_taxa(physeq1, Class != "Chloroplast") # dropped 89 ASVs
  physeq3 <- subset_taxa(physeq2, Family != "Mitochondria") # dropped 159 ASVs
  
  physeq <- physeq3 # 9600 ASVs
  
  phyloseq-class experiment-level object
  otu_table()   OTU Table:         [ 9600 taxa and 573 samples ]
  sample_data() Sample Data:       [ 573 samples by 13 sample variables ]
  tax_table()   Taxonomy Table:    [ 9600 taxa by 7 taxonomic ranks ]
  phy_tree()    Phylogenetic Tree: [ 9600 tips and 9599 internal nodes ]
    
  # Create a complete mapping file
 
  physeq_eggs <- subset_samples(physeq, SampleType == "egg")
   
      phyloseq-class experiment-level object
      otu_table()   OTU Table:         [ 9600 taxa and 274 samples ]
      sample_data() Sample Data:       [ 274 samples by 13 sample variables ]
      tax_table()   Taxonomy Table:    [ 9600 taxa by 7 taxonomic ranks ]
      phy_tree()    Phylogenetic Tree: [ 9600 tips and 9599 internal nodes ]
 
  physeq_cloaca <- subset_samples(physeq, SampleType == "cloaca")    
  
      phyloseq-class experiment-level object
      otu_table()   OTU Table:         [ 9600 taxa and 228 samples ]
      sample_data() Sample Data:       [ 228 samples by 13 sample variables ]
      tax_table()   Taxonomy Table:    [ 9600 taxa by 7 taxonomic ranks ]
      phy_tree()    Phylogenetic Tree: [ 9600 tips and 9599 internal nodes ]
      
  physeq_soil <- subset_samples(physeq, SampleType == "soil")    
      
      phyloseq-class experiment-level object
      otu_table()   OTU Table:         [ 9600 taxa and 69 samples ]
      sample_data() Sample Data:       [ 69 samples by 13 sample variables ]
      tax_table()   Taxonomy Table:    [ 9600 taxa by 7 taxonomic ranks ]
      phy_tree()    Phylogenetic Tree: [ 9600 tips and 9599 internal nodes ]
      
  physeq_NC <- subset_samples(physeq, SampleType == "NC")       
  
      phyloseq-class experiment-level object
      otu_table()   OTU Table:         [ 9600 taxa and 2 samples ]
      sample_data() Sample Data:       [ 2 samples by 13 sample variables ]
      tax_table()   Taxonomy Table:    [ 9600 taxa by 7 taxonomic ranks ]
      phy_tree()    Phylogenetic Tree: [ 9600 tips and 9599 internal nodes ]
  
  mapping_seqs <- as(sample_data(physeq), "data.frame")
    mapping_seqs_eggs <- subset(mapping_seqs, SampleType == "egg") # n= 274
    mapping_seqs_cloaca <- subset(mapping_seqs, SampleType == "cloaca") # n= 228
    mapping_seqs_soil <- subset(mapping_seqs, SampleType == "soil") # n= 69
    
  metadata_eggs <- read.table("Metadata_eggs_20180306.txt",sep = "\t",dec = ".", header = T )
  metadata_cloaca <- read.table("mappingfile_cloacalonly_final_validatedImmuneIndices.txt",sep = "\t",dec = ".", header = T )
  metadata_soil <- read.table("mapping_metadata_file_soilonly_20170328_final_corrected_corrected.txt",sep = "\t",dec = ".", header = T )

  nrow(metadata_eggs) # n = 443
  nrow(metadata_cloaca) # n = 230
  nrow(metadata_soil) # n = 71
  
  mapping_meta_merged_eggs <- join(mapping_seqs_eggs, metadata_eggs, by = "SampleID", type="inner")
  mapping_meta_merged_cloaca <- join(mapping_seqs_cloaca, metadata_cloaca, by = "SampleID", type="inner")
  mapping_meta_merged_soil <- join(mapping_seqs_soil, metadata_soil, by = "SampleID", type="inner")
  
  nrow(mapping_meta_merged_eggs) # n = 274
  nrow(mapping_meta_merged_cloaca) # n = 228
  nrow(mapping_meta_merged_soil) # n = 69
  
  # settdfiff for difference in n
  setdiff(mapping_seqs_soil$SampleID, metadata_soil$SampleID) # NC1 and NC8 make the difference
  
  # subset only eggs laid in clutches (so not randomly before having a nest)
  mapping_meta_merged_eggs_c12 <- subset(mapping_meta_merged_eggs, clutch_nr != 0)
  nrow(mapping_meta_merged_eggs_c12) # 265
  # add categorical incubation factor
  mapping_meta_merged_eggs_c12$IncubationFac <- ifelse(mapping_meta_merged_eggs_c12$incubation_days == 0, "no", "yes")
  
  # inspect that colnames are equal when shared
  colnames(mapping_meta_merged_eggs_c12)
  colnames(mapping_meta_merged_cloaca)
  colnames( mapping_meta_merged_soil)
  
  # make adjustments to equalise
  colnames(mapping_meta_merged_eggs_c12)[19] <- "cage"
  mapping_meta_merged_cloaca <- mapping_meta_merged_cloaca[,-c(14:16,18,19,21,22)]
  is.factor(mapping_meta_merged_eggs_c12$ring_ID)
  mapping_meta_merged_cloaca$cage <- as.factor(mapping_meta_merged_cloaca$cage)
  mapping_meta_merged_cloaca$ring_ID <- as.factor(mapping_meta_merged_cloaca$ring_ID)
  colnames(mapping_meta_merged_soil)[11] <- "TypeCode"
  colnames(mapping_meta_merged_soil)[12] <- "SampleNr"
  colnames(mapping_meta_merged_soil)[28] <- "room"
  mapping_meta_merged_soil$exp <- ifelse(mapping_meta_merged_soil$GroupExp == "N", "control", "treatment")
  mapping_meta_merged_soil <- mapping_meta_merged_soil[,-c(31:33)]
  mapping_meta_merged_soil$Timepoint_days <- ifelse( mapping_meta_merged_soil$Timepoint == 0.0, 0, ifelse(mapping_meta_merged_soil$Timepoint==0.5, 3, ifelse(mapping_meta_merged_soil$Timepoint == 1.5, 10, 14)))
  nrow(mapping_meta_merged_soil)
  
  # merge together egg and cloacal
  mapping_subfinal <- full_join(mapping_meta_merged_eggs_c12, mapping_meta_merged_cloaca)
  nrow(mapping_subfinal) # != 274+228 = 502 ...
  
  # these 9 samples make the difference
  subset(mapping_meta_merged_eggs, clutch_nr == 0)
  list_rm <- c(as.character(subset(mapping_meta_merged_eggs, clutch_nr == 0)$SampleID))
  
  # merge together merged_egg_cloacal and soil
  mapping_final <- full_join(mapping_subfinal, mapping_meta_merged_soil)
  nrow(mapping_final)
  
  
  # which samples to remove from physeq (NC1, NC8, list_rm)
  rm_final_list <- c("NC1", "NC8", list_rm)
  
  # phyloseq object containing metadata and having all but clutch==0 and NC1 and NC8 samples
  physeq_data <- subset_samples(physeq, ! SampleID %in% rm_final_list)
  
  # replace sample_data(physeq_data) with mapping_metadata combination
  
  mapping_meta_final <- sample_data(mapping_final)
  sample_names(mapping_meta_final) <- sample_data(mapping_final)$SampleID
  
  sample_data(physeq_data) <- mapping_meta_final
  
  # final phyloseq object containing 69 soil, 265 eggs and 228 clocoal samples
  physeq_data
  
  