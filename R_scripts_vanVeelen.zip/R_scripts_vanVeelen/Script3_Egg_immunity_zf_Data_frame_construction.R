### This R script belongs to van Veelen et al. The microbial environment modulates non-genetic maternal effects on egg immunity


### With this script immune function data of zebra finch females and eggs have been analysed.
 
### For questions, contact Pieter van Veelen (pietervanveelen2@gmail.com)


##############################################

### Data pre-processing Zebra Finch egg immunity and maternal transfer ###

setwd("/Users/pietervanveelen/Google Drive/Rdata backups/CH6_Egg_immunity_zf")

## input files
  # metadata general eggs only
  metadata <- read.table("Metadata_eggs_drylab_20180327.txt", sep = "\t", dec = ".", header = T)
  # IgY absorbance
  yolk_IgY <- read.table("IgY_mean_data_zf_eggshell_20180312.txt", sep = "\t", dec = ".", header = T)
  # lysozyme concentration
  albumen_lysozyme <- read.table("lysozyme_20180327.txt", sep = "\t", dec = ".", header = T)
  # ovotransferrin concentration
  albumen_ovotransferrin <- read.table("ovotransferrin_egg_zf_20180327.txt", sep = "\t", dec = ".", header = T)
  albumen_ovotransferrin <- albumen_ovotransferrin[!is.na(albumen_ovotransferrin$ovotransferrin),]
  # Albumen pH
  albumen_pH <- read.table("pH_Egg_Albumen_ZebraFinch_6314A_20180327.txt", sep = "\t", dec = ".", header = T)
  
  # create datasframe with all immune indices
  data_egg_immunity <- join(metadata, yolk_IgY, by = "NumberID", type = "left")
  data_egg_immunity <- join(data_egg_immunity, albumen_lysozyme[,c("NumberID", "lyso")], by = "NumberID", type = "left")
  data_egg_immunity <- join(data_egg_immunity, albumen_ovotransferrin[,c("NumberID", "ovotransferrin")], by = "NumberID", type = "left")
  data_egg_immunity <- join(data_egg_immunity, albumen_pH[,c("NumberID", "pH")], by = "NumberID", type = "left")
  
  # rename IgYmean for egg yolks, so it does not trouble merging of data frames with female plasma IgYmean
  names(data_egg_immunity)[17] <- "IgYmean_yolk"
  
  # rename SampleID to match sequence data format SampleIDs
  data_egg_immunity$SampleID <- paste0("6314A.E",data_egg_immunity$NumberID)
  
  # create separate dataframe for eggs with data on each immune index (!is.na)
  data_egg_immunity_allnoNA <-  data_egg_immunity %>%
    subset(
      !is.na(IgYmean_yolk) & 
        !is.na(lyso) &
        !is.na(ovotransferrin) & 
        !is.na(pH) 
    )
  
  
  # load physeq_data with phyloseq object containing unfiltered ASVs
  load(file = "CH6_zf_egg_immunity/zf_eggshell_cloacal_soil_physeq_data.rda")
  physeq_data

  # extract metadata from sample_data() of phyloseq object as data frame
  physeq_metadata <- as(sample_data(physeq_data), "data.frame")
  physeq_metadata$Sampling_date_weights <- as.Date(physeq_metadata$Sampling_date_weights, format="%d/%m/%Y")
  
  # add IgY data of females ("Female_sample_mean_SerumIgY_20170428.txt")
  IgY_samples <- read.table("CH6_zf_egg_immunity/Female_sample_mean_SerumIgY_20170428.txt", dec = ".", sep = "\t", header = TRUE)
  colnames(IgY_samples)[1] <- "Sampling_date_weights"
  IgY_samples$Sampling_date_weights <- as.Date(IgY_samples$Sampling_date_weights, format="%d/%m/%Y")
  #IgY_samples$Sampling_date <- gsub("-","/",IgY_samples$Sampling_date)
  #IgY_samples$Sampling_date_weights <- as.Date(gsub("-","/",IgY_samples$Sampling_date_weights), format="%Y/%m/%d")
  nrow(IgY_samples)
  head(IgY_samples)
  library(plyr)
  immune_data2 <- join(physeq_metadata,IgY_samples[,c("ring_ID","Sampling_date_weights","mean_value")], by = c("ring_ID","Sampling_date_weights"), type="left" )
  head(immune_data2)
  colnames(immune_data2)[74] <- "IgYmean"
  View(immune_data2)
  
  # join physeq metadata with egg immune measures
  physeq_metadata_immune <- join(immune_data2, data_egg_immunity[,c("SampleID", "IgYmean_yolk", "lyso", "ovotransferrin", "pH")], by = "SampleID", type = "left")
  physeq_metadata_immune$SampleID <- as.character(physeq_metadata_immune$SampleID)
  # replace old sample_data() from physeq_data with physeq_metadata_immune including female IgY, yolk IgY, albumen Lysozyme Ovotransferrin and pH data
  
  new_sample_data <- sample_data(physeq_metadata_immune)
  sample_names(new_sample_data) <- physeq_metadata_immune$SampleID
  sample_data(physeq_data) <- new_sample_data
  
  # completed physeq object including immune functin data of females and eggs
  physeq_data
  
  saveRDS(physeq_data)
  # subset cloacal data
  physeq_cloaca <- subset_samples(physeq_data, SampleType == "cloaca")
  physeq_cloaca <- prune_taxa(taxa_sums(physeq_cloaca) > 0, physeq_cloaca)
  hist(sample_sums(physeq_cloaca))
  summary(sample_sums(physeq_cloaca))  
  quantile(summary(sample_sums(physeq_cloaca)), 0.1) # 10th%-ile = 676.375
  quantile(summary(sample_sums(physeq_cloaca)), 0.2) # 20th%-ile = 1344.75
  physeq_cloaca_top90 <- prune_samples(sample_sums(physeq_cloaca) > 676, physeq_cloaca) # 196 cloacae retained; 32 lost
  list_retain_cloaca <- c(as.character(sample_data(physeq_cloaca_top90)$SampleID))
  
  # subset egg samples
  physeq_egg <- subset_samples(physeq_data, SampleType == "egg")
  physeq_egg <- prune_taxa(taxa_sums(physeq_egg) > 0, physeq_egg)  
  physeq_egg  
  quantile(summary(sample_sums(physeq_egg)), 0.1) # 10th%-ile = 157.5  
  quantile(summary(sample_sums(physeq_egg)), 0.2) # 20th%-ile = 313  
  physeq_egg_top80 <- prune_samples(sample_sums(physeq_egg) > 313, physeq_egg) # 198 eggs retained; 67 lost  
  list_retain_egg <- c(as.character(sample_data(physeq_egg_top80)$SampleID))
 
  # combine egg and cloacal data
  list_SampleType_compar <- c(list_retain_egg,list_retain_cloaca)
  physeq_SampleType_compar <- subset_samples(physeq_data, SampleID %in% list_SampleType_compar) # retaining 463 samples
  ss_egg80 <- sample_sums(physeq_egg_top80)  
  ss_cloacal90 <- sample_sums(physeq_cloaca_top90)  
  kruskal.test(list(ss_egg80, ss_cloacal90)) # medians differ: Kruskal-Wallis rank sum test  
  sapply(list(ss_egg80, ss_cloacal90), FUN = summary)  
  4360.500/3101.00  = 1.41 # is ok (cf. Weiss et al.)

  #  
  physeq_SampleType_compar <- prune_taxa(taxa_sums(physeq_SampleType_compar) > 0, physeq_SampleType_compar)
  physeq_SampleType_compar  
  is.factor(sample_data(physeq_SampleType_compar)$exp) # F
  
  ## make sure that explanatory variables are factors/integers/numerical where needed
  sample_data(physeq_SampleType_compar)$exp <-  as.factor(sample_data(physeq_SampleType_compar)$exp)
  sample_data(physeq_SampleType_compar)$clutch_nr <- as.factor(sample_data(physeq_SampleType_compar)$clutch_nr)
  sample_data(physeq_egg_top80)$exp <- as.factor(sample_data(physeq_egg_top80)$exp) 
  sample_data(physeq_egg_top80)$clutch_nr <- as.factor(sample_data(physeq_egg_top80)$clutch_nr)
  
  ## Input dataframes:
  physeq_egg_top80 <- prune_taxa(taxa_sums(physeq_egg_top80) > 0, physeq_egg_top80)
  physeq_egg_top80  

  # DESeq2 VST transformation of egg data
  dds_egg80_compar <- phyloseq_to_deseq2(physeq_egg_top80, ~ exp + clutch_nr)
  dds_egg80_compar
  # estimate size factors (to control for library size effects on downstream results)
  dds_egg80_compar <- estimateSizeFactors(dds_egg80_compar)
  # calculate geometric means prior to estimate size factors
  gm_mean = function(x, na.rm=TRUE){
    exp(sum(log(x[x > 0]), na.rm=na.rm) / length(x))
  }
  # calculate geometric means
  geoMeans <- apply(counts(dds_egg80_compar), 1, gm_mean)
  # estimate Size Factors specifying geoMeans
  dds_egg80_compar <- estimateSizeFactors(dds_egg80_compar, geoMeans=geoMeans)
  sizeFactors(dds_egg80_compar)
  # estimate Dispersions specifying geoMeans  
  dds_egg80_compar <- estimateDispersions(dds_egg80_compar)  
  dispersions(dds_egg80_compar)  
  
  # run variance stabilizing transformation (vst) or rlog transformation if size factors vary greatly (FALSE here)
  detach("package:DESeq", unload=TRUE)
  dds_egg80_compar_vst <- varianceStabilizingTransformation(dds_egg80_compar)  
  physeq_egg_top80  
  physeq_egg_top80_noTrans <- physeq_egg_top80
  physeq_egg_top80_vst <- physeq_egg_top80  
  # store variance stabilised transformed otu table in physeq_egg_top80_vst
  otu_table(physeq_egg_top80_vst) <- otu_table(assay(dds_egg80_compar_vst), taxa_are_rows = TRUE)
  otu_table(physeq_egg_top80_vst)[1:5,1:5]  
  # set negative transformed values to ZERO (as they are estimated to be close to zero based on the fitted NegBin model: the more negative, the more likely to be true 0)
  otu_table(physeq_egg_top80_vst)[otu_table(physeq_egg_top80_vst) < 0] <- 0
  otu_table(physeq_egg_top80_vst)[1:5,1:5]  

  # Beta diversity analysis on original physeq object
  df_physeq_egg_top80_vst <- as.data.frame(sample_data(physeq_egg_top80_vst)@.Data)
  colnames(df_physeq_egg_top80_vst) <- sample_data(physeq_egg_top80_vst)@names  
  df_physeq_egg_top80_vst  
  egg80_vst_wunifr <- UniFrac(physeq_egg_top80_vst, weighted = T, normalized = T)  
  egg80_vst_uunifr <- UniFrac(physeq_egg_top80_vst, weighted = F, normalized = F)  

  # create data_egg_immunity_allnoNA 
  nrow(data_egg_immunity)
  
  data_egg_immunity_allnoNA <-  data_egg_immunity %>%
    subset(
      !is.na(IgYmean_yolk) &
      !is.na(lyso) &
      !is.na(ovotransferrin) &
      !is.na(pH)
    )
  nrow(data_egg_immunity_allnoNA)  
  
  
# physeq data
  physeq_data

  save(physeq_data, file = "zf_eggshell_cloacal_soil_physeq_data_20180821.rda")  
  
  # create physeq with eggs only
  physeq_egg <- subset_samples(physeq_data, SampleType == "egg")
  physeq_egg  

  physeq_metadata <- as(sample_data(physeq_data), "data.frame")
  names(data_egg_immunity)  
  # female IgY data
  # add IgY data of females ("Female_sample_mean_SerumIgY_20170428.txt")
  IgY_samples <- read.table(file.choose(), dec = ".", sep = "\t", header = TRUE)
  IgY_samples  
  IgY_samples$Sampling_date <- as.Date(IgY_samples$Sampling_date, format="%d/%m/%Y")
  nrow(IgY_samples)

  # merge female and egg IgY data
  immune_data2 <- join(physeq_metadata,IgY_samples, by = c("ring_ID","Sampling_date_weights"), type="left" )
  subset(immune_data2, SampleType == "cloaca")
  names(physeq_metadata)  
  names(IgY_samples)  
  
  IgY_samples$Sampling_date_weights <- as.factor(IgY_samples$Sampling_date_weights)
  physeq_metadata$ring_ID <- as.factor(physeq_metadata$ring_ID)
  IgY_samples$ring_ID <- as.factor(as.character(IgY_samples$ring_ID))
  
  physeq_metadata$Sampling_date_weights <- as.Date(physeq_metadata$Sampling_date_weights, format="%d/%m/%Y")
  str(physeq_metadata)
  
  IgY_samples$Sampling_date_weights <- gsub("-","/",IgY_samples$Sampling_date_weights)
  IgY_samples$Sampling_date_weights <- as.Date(IgY_samples$Sampling_date_weights, format="%Y/%m/%d")
  str(IgY_samples)
  
  intersect(colnames(IgY_samples), colnames(physeq_metadata))
  immune_data2 <- join(physeq_metadata,IgY_samples[,c("ring_ID","Sampling_date_weights","mean_value")], by = c("ring_ID","Sampling_date_weights"), type="left" )  
  immune_data2$mean_value
  immune_data2[!is.na(immune_data2$Sampling_date_weights),]
  nrow(immune_data2)  
  colnames(immune_data2)[74] <- "IgYmean"
  immune_data2$IgYmean
  
  # data on egg immunity
  data_egg_immunity  
  data_egg_immunity[,c("SampleID", "IgYmean_yolk", "lyso", "ovotransferrin", "pH")]
  head(immune_data2)  
  # join physeq metadata with egg immune measures
  data_egg_immunity$SampleID <- gsub("_", ".E", data_egg_immunity$SampleID)
  data_egg_immunity <- join(metadata, yolk_IgY, by = "NumberID", type = "left")
  data_egg_immunity <- join(data_egg_immunity, albumen_lysozyme[,c("NumberID", "lyso")], by = "NumberID", type = "left")
  data_egg_immunity <- join(data_egg_immunity, albumen_ovotransferrin[,c("NumberID", "ovotransferrin")], by = "NumberID", type = "left")  
  data_egg_immunity <- join(data_egg_immunity, albumen_pH[,c("NumberID", "pH")], by = "NumberID", type = "left")  
  # rename IgYmean for egg yolks, so it does not trouble merging of data frames with female plasma IgYmean
  names(data_egg_immunity)[17] <- "IgYmean_yolk"
  paste0("6314A.E",data_egg_immunity$NumberID)  
  data_egg_immunity$SampleID <- paste0("6314A.E",data_egg_immunity$NumberID)  
  intersect(immune_data2$SampleID, data_egg_immunity$SampleID )  
  # join physeq metadata with egg immune measures
  physeq_metadata_immune <- join(immune_data2, data_egg_immunity[,c("SampleID", "IgYmean_yolk", "lyso", "ovotransferrin", "pH")], by = "SampleID", type = "left")
  dim(physeq_metadata_immune)
  # check different data types
  head(subset(physeq_metadata_immune, SampleType == "egg"))  
  head(subset(physeq_metadata_immune, SampleType == "cloaca"))  
  sample_data(physeq_metadata_immune)
  
  # number of females after laying
  nrow(subset(subset(physeq_metadata_immune, SampleType == "cloaca"), sampling_point == 5))
  
  
  physeq_metadata_immune$SampleID <- as.character(physeq_metadata_immune$SampleID)
  physeq_metadata_immune$egg_nr[4] <- 3
  physeq_metadata_immune$egg_nr[99] <- 4
  physeq_metadata_immune$egg_nr <- as.integer(as.character(physeq_metadata_immune$egg_nr))
  
  new_sample_data <- sample_data(physeq_metadata_immune)
  sample_names(new_sample_data) <- physeq_metadata_immune$SampleID  
  sample_names(new_sample_data)  
  new_sample_data  
  sample_data(physeq_data) <- new_sample_data  
  
  physeq_data # completed physeq object including immune functin data of females and eggs
 
  ###
  
  ## calculate repeatabilities of egg immune indices ##
  
  # lysozyme
  rpt(log(lyso) ~ exp + clutch_nr + egg_nr + (1|ring_ID) + (1|room) , data = subset(physeq_metadata_immune, SampleType == "egg"), 
      grname = "ring_ID", datatype = "Gaussian", nboot = 1000, npermut = 1000, adjusted = T)
  
      Repeatability estimation using the lmm method 
      
      Repeatability for ring_ID
      R  = 0.268
      SE = 0.097
      CI = [0.089, 0.468]
      P  = 0.000534 [LRT]
      0.003 [Permutation]
  
  rpt(ovotransferrin ~ exp + clutch_nr + egg_nr + (1|ring_ID) + (1|room) , data = subset(physeq_metadata_immune, SampleType == "egg"), 
      grname = "ring_ID", datatype = "Gaussian", nboot = 1000, npermut = 1000, adjusted = T)
      
      Repeatability estimation using the lmm method 
      
      Repeatability for ring_ID
      R  = 0
      SE = 0.06
      CI = [0, 0.205]
      P  = 1 [LRT]
      1 [Permutation]
  
  
  rpt(IgYmean_yolk ~ exp + clutch_nr + egg_nr + (1|ring_ID) + (1|room) , data = subset(physeq_metadata_immune, SampleType == "egg"), 
          grname = "ring_ID", datatype = "Gaussian", nboot = 1000, npermut = 1000, adjusted = T)
      
      Repeatability estimation using the lmm method 
      
      Repeatability for ring_ID
      R  = 0.804
      SE = 0.113
      CI = [0.503, 0.923]
      P  = 1.65e-46 [LRT]
      0.001 [Permutation]
      
      
  ### anova to test experimental effect on egg immune indices ###
      
  lmer_lyso <- lmer(log(lyso) ~ exp + clutch_nr + egg_nr + pH + (1|ring_ID) + (1|room) , data = subset(physeq_metadata_immune, SampleType == "egg"))
  hist(resid(lmer_lyso))
  plot(resid(lmer_lyso) ~ fitted(lmer_lyso))
  anova(lmer_lyso)
  
          Sum Sq Mean Sq NumDF   DenDF F.value  Pr(>F)  
          exp       0.00269 0.00269     1  32.524 0.00770 0.93060  
          clutch_nr 1.85888 0.92944     2 121.168 2.65966 0.07406 .
          egg_nr    0.05462 0.05462     1 129.695 0.15631 0.69323  
          pH        0.21938 0.21938     1 124.093 0.62777 0.42969  
          ---
            Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
      
          
   summary(lmer_lyso)    
   
          Linear mixed model fit by REML 
          t-tests use  Satterthwaite approximations to degrees of freedom ['lmerMod']
          Formula: log(lyso) ~ exp + clutch_nr + egg_nr + pH + (1 | ring_ID) + (1 |      room)
          Data: subset(physeq_metadata_immune, SampleType == "egg")
          
          REML criterion at convergence: 290.1
          
          Scaled residuals: 
            Min      1Q  Median      3Q     Max 
          -2.0231 -0.6067 -0.0787  0.5193  2.5885 
          
          Random effects:
            Groups   Name        Variance Std.Dev.
          ring_ID  (Intercept) 0.1331   0.3648  
          room     (Intercept) 0.0000   0.0000  
          Residual             0.3495   0.5911  
          Number of obs: 141, groups:  ring_ID, 35; room, 2
          
          Fixed effects:
            Estimate Std. Error        df t value Pr(>|t|)  
          (Intercept)    2.26656    2.62323 125.12000   0.864   0.3892  
          exptreatment   0.01418    0.16161  32.52000   0.088   0.9306  
          clutch_nr2     0.23943    0.10713 117.93000   2.235   0.0273 *
            clutch_nr3     0.36682    0.40571 125.45000   0.904   0.3676  
          egg_nr         0.02399    0.06069 129.69000   0.395   0.6932  
          pH            -0.21371    0.26973 124.09000  -0.792   0.4297  
          ---
            Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
          
          Correlation of Fixed Effects:
            (Intr) exptrt cltc_2 cltc_3 egg_nr
          exptreatmnt  0.015                            
          clutch_nr2  -0.128 -0.024                     
          clutch_nr3  -0.212 -0.007  0.153              
          egg_nr      -0.429  0.023 -0.006  0.305       
          pH          -0.996 -0.052  0.115  0.189  0.361
        
  lmer_ovo <- lmer(ovotransferrin ~ exp + clutch_nr + egg_nr + pH + (1|ring_ID) + (1|room) , data = subset(physeq_metadata_immune, SampleType == "egg"))
  hist(resid(lmer_ovo))
  plot(resid(lmer_ovo) ~ fitted(lmer_ovo))
  anova(lmer_ovo)
    
            Analysis of Variance Table of type III  with  Satterthwaite 
            approximation for degrees of freedom
            Sum Sq Mean Sq NumDF DenDF F.value    Pr(>F)    
            exp        12.343  12.343     1   116  1.9322   0.16718    
            clutch_nr  42.869  21.435     2   116  3.3555   0.03831 *  
            egg_nr    126.981 126.981     1   116 19.8783 1.917e-05 ***
            pH          1.324   1.324     1   116  0.2073   0.64972    
          ---
            Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
      
  summary(lmer_ovo)
  
            Linear mixed model fit by REML 
            t-tests use  Satterthwaite approximations to degrees of freedom ['lmerMod']
            Formula: ovotransferrin ~ exp + clutch_nr + egg_nr + pH + (1 | ring_ID) +      (1 | room)
            Data: subset(physeq_metadata_immune, SampleType == "egg")
            
            REML criterion at convergence: 563.4
            
            Scaled residuals: 
              Min      1Q  Median      3Q     Max 
            -1.8143 -0.6523 -0.2078  0.4252  3.5583 
            
            Random effects:
              Groups   Name        Variance  Std.Dev. 
            ring_ID  (Intercept) 3.727e-14 1.931e-07
            room     (Intercept) 8.253e-48 2.873e-24
            Residual             6.388e+00 2.527e+00
            Number of obs: 122, groups:  ring_ID, 34; room, 2
            
            Fixed effects:
              Estimate Std. Error       df t value Pr(>|t|)    
            (Intercept)   13.7519    11.1810 116.0000   1.230   0.2212    
            exptreatment   0.6455     0.4644 116.0000   1.390   0.1672    
            clutch_nr2    -0.4923     0.4697 116.0000  -1.048   0.2969    
            clutch_nr3    -3.9018     1.5741 116.0000  -2.479   0.0146 *  
              egg_nr        -1.1068     0.2482 116.0000  -4.459 1.92e-05 ***
              pH            -0.5245     1.1518 116.0000  -0.455   0.6497    
            ---
              Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
            
            Correlation of Fixed Effects:
              (Intr) exptrt cltc_2 cltc_3 egg_nr
            exptreatmnt  0.086                            
            clutch_nr2  -0.106  0.004                     
            clutch_nr3  -0.189 -0.038  0.121              
            egg_nr      -0.460 -0.008 -0.077  0.310       
            pH          -0.997 -0.112  0.095  0.167  0.401
        
  
  lmer_IgYmean_yolk <- lmer(IgYmean_yolk ~ exp + clutch_nr + egg_nr + (1|ring_ID) + (1|room) , data = subset(physeq_metadata_immune, SampleType == "egg"))
  hist(resid(lmer_IgYmean_yolk))
  plot(resid(lmer_IgYmean_yolk) ~ fitted(lmer_IgYmean_yolk))
  anova(lmer_IgYmean_yolk)
  
        Analysis of Variance Table of type III  with  Satterthwaite 
        approximation for degrees of freedom
        Sum Sq  Mean Sq NumDF   DenDF F.value    Pr(>F)    
        exp       0.06079 0.060793     1  32.934  2.1137 0.1554523    
        clutch_nr 0.42729 0.213645     2 120.464  7.4281 0.0009077 ***
        egg_nr    0.07249 0.072489     1 121.044  2.5203 0.1149963    
      ---
        Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
      
            
        
 summary(lmer_IgYmean_yolk)
      
       Linear mixed model fit by REML 
       t-tests use  Satterthwaite approximations to degrees of freedom ['lmerMod']
       Formula: IgYmean_yolk ~ exp + clutch_nr + egg_nr + (1 | ring_ID) + (1 |      room)
       Data: subset(physeq_metadata_immune, SampleType == "egg")
       
       REML criterion at convergence: 26.8
       
       Scaled residuals: 
         Min      1Q  Median      3Q     Max 
       -2.4451 -0.5678 -0.0203  0.5133  3.3677 
       
       Random effects:
         Groups   Name        Variance  Std.Dev. 
       ring_ID  (Intercept) 2.289e-01 4.785e-01
       room     (Intercept) 6.257e-15 7.910e-08
       Residual             2.876e-02 1.696e-01
       Number of obs: 157, groups:  ring_ID, 35; room, 2
       
       Fixed effects:
         Estimate Std. Error        df t value Pr(>|t|)    
       (Intercept)    1.39768    0.13036  48.45000  10.721 2.18e-14 ***
        exptreatment  -0.23895    0.16436  32.93000  -1.454 0.155452    
        clutch_nr2    -0.11447    0.02970 120.51000  -3.854 0.000188 ***
        clutch_nr3    -0.05952    0.11780 120.46000  -0.505 0.614260    
        egg_nr         0.02543    0.01602 121.04000   1.588 0.114996    
       ---
         Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1  
        
    ### plots egg immunity
        
        ggplot(data = subset(physeq_metadata_immune, SampleType == "egg"), aes(x = exp, y = log(lyso))) +
          geom_point(aes(shape = clutch_nr, colour = as.factor(egg_nr)), size = 2, position = position_dodge(0.3))
  
    ## RDA egg immunity
        
    data_egg_immunity_allnoNA <-  data_egg_immunity %>%
        subset(
           !is.na(IgYmean_yolk) &
           !is.na(lyso) &
           !is.na(ovotransferrin) &
           !is.na(pH)
         )
  
    nrow(data_egg_immunity_allnoNA) # n=115
    names(data_egg_immunity_allnoNA)
    data_egg_immunity_allnoNA$egg_nr <- as.integer(as.character(data_egg_immunity_allnoNA$egg_nr))
    data_egg_immunity_allnoNA$egg_nr[8] <- 3
    data_egg_immunity_allnoNA$egg_nr[46] <- 4
    # distance matrix Bray
    data_egg_immunity_allnoNA_forRDA <- data_egg_immunity_allnoNA[,c(17,19,20)]
    bray_immune_egg_all_noNA <- vegdist(data_egg_immunity_allnoNA_forRDA, binary = F, na.rm = TRUE)
    
    # RDA
      RDA_immune_egg <- capscale(bray_immune_egg_all_noNA ~ exp + clutch_nr + egg_nr, sqrt.dist= TRUE, data = data_egg_immunity_allnoNA)
      
      anova(RDA_immune_egg, by = "terms")
      Permutation test for capscale under reduced model
      Terms added sequentially (first to last)
      Permutation: free
      Number of permutations: 999
      
      Model: capscale(formula = bray_immune_egg_all_noNA ~ exp + clutch_nr + egg_nr, data = data_egg_immunity_allnoNA, sqrt.dist = TRUE)
      Df SumOfSqs      F Pr(>F)    
      exp        1   0.1548 1.2999  0.199    
      clutch_nr  1   0.1935 1.6255  0.111    
      ring_ID   34   6.9330 1.7126  0.001 ***
      Residual  78   9.2872                  
      ---
        Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
      
      plot(RDA_immune_egg)
      
      
### Beta diversity ###
      
      physeq_cloaca_top90
      
      # subset cloacal samples after egg laying
      
      physeq_cloaca_top90_t5 <- subset_samples(physeq_cloaca_top90, sampling_point == 5)
      
      physeq_cloaca_top90_t5
      list_retain_egg <- c(as.character(sample_data(physeq_egg_top80)$SampleID))
      list_retain_cloaca <- c(as.character(sample_data(physeq_cloaca_top90_t5)$SampleID))
      list_SampleType_compar <- c(list_retain_egg,list_retain_cloaca)      
      physeq_SampleType_compar <- subset_samples(physeq_data, SampleID %in% list_SampleType_compar) # retaining 238 samples      
      ss_egg80 <- sample_sums(physeq_egg_top80)
      ss_cloacal90 <- sample_sums(physeq_cloaca_top90)
      kruskal.test(list(ss_egg80, ss_cloacal90))  
          
          Kruskal-Wallis rank sum test
          
          data:  list(ss_egg80, ss_cloacal90)
          Kruskal-Wallis chi-squared = 12.469, df = 1, p-value = 0.0004138
          
      sapply(list(ss_egg80, ss_cloacal90), FUN = summary)

          [,1]      [,2]
          Min.      339.00   726.000
          1st Qu.  1068.50  1789.250
          Median   3101.00  4360.500
          Mean     4642.47  6719.531
          3rd Qu.  6433.25  8404.250
          Max.    24815.00 78049.000
      
          4360.500/3101.00 = 1.41
          
          ## Input dataframes:
          #physeq_SampleType_compar <- prune_taxa(taxa_sums(physeq_SampleType_compar) > 0, physeq_SampleType_compar)
          #physeq_SampleType_compar
          
          #str(sample_data(physeq_SampleType_compar))

          # create phyloseq_to_deseq2 DESeq2 object          
          ## make sure that explanatory variables are factors/integers/numerical where needed          
          sample_data(physeq_cloaca_top90_t5)$exp <- as.factor(sample_data(physeq_cloaca_top90_t5)$exp)
          sample_data(physeq_cloaca_top90_t5)$clutch_nr <- as.factor(sample_data(physeq_cloaca_top90_t5)$clutch_nr)
          sample_data(physeq_cloaca_top90_t5)$egg_nr <- as.integer(as.character(sample_data(physeq_cloaca_top90_t5)$egg_nr))
          sample_data(physeq_cloaca_top90_t5)$room <- as.factor(sample_data(physeq_cloaca_top90_t5)$room)
          is.factor(sample_data(physeq_cloaca_top90_t5)$exp)

          physeq_egg_top80          
          physeq_egg_top80 <- prune_taxa(taxa_sums(physeq_egg_top80) > 0, physeq_egg_top80)
          physeq_egg_top80
          sample_data(physeq_egg_top80)$exp <- as.factor(sample_data(physeq_egg_top80)$exp)
          sample_data(physeq_egg_top80)$clutch_nr <- as.factor(sample_data(physeq_egg_top80)$clutch_nr)          
          sample_data(physeq_egg_top80)$egg_nr <- as.integer(as.character(sample_data(physeq_egg_top80)$clutch_nr))
          sample_data(physeq_egg_top80)$room <- as.factor(sample_data(physeq_egg_top80)$room)          

          # phyloseq to deseq
          dds_physeq_cloaca_top90_t5 <- phyloseq_to_deseq2(physeq_cloaca_top90_t5, ~ exp)
          dds_egg80_compar <- phyloseq_to_deseq2(physeq_egg_top80, ~ exp + clutch_nr)
          
          # calculate geometric means prior to estimate size factors
          gm_mean = function(x, na.rm=TRUE){
            exp(sum(log(x[x > 0]), na.rm=na.rm) / length(x))
            }
          
          # calculate geometric means
          geoMeans_physeq_cloaca_top90_t5 <- apply(counts(dds_physeq_cloaca_top90_t5), 1, gm_mean)
          geoMeans <- apply(counts(dds_egg80_compar), 1, gm_mean)
          
          
          # estimate size factors (to control for library size effects on downstream results)
          dds_physeq_cloaca_top90_t5 <- estimateSizeFactors(dds_physeq_cloaca_top90_t5, geoMeans=geoMeans_physeq_cloaca_top90_t5)
          dds_egg80_compar <- estimateSizeFactors(dds_egg80_compar, geoMeans=geoMeans)
          
          # estimate Dispersions specifying geoMeans
          dds_physeq_cloaca_top90_t5 <- estimateDispersions(dds_physeq_cloaca_top90_t5)
          dds_egg80_compar <- estimateDispersions(dds_egg80_compar)
          
          # run variance stabilizing transformation (vst) or rlog transformation if size factors vary greatly (FALSE here)
          dds_physeq_cloaca_top90_t5 <- varianceStabilizingTransformation(dds_physeq_cloaca_top90_t5)
          dds_egg80_compar_vst <- varianceStabilizingTransformation(dds_egg80_compar)
          
          # old and new phyloseq objects
          physeq_cloaca_top90_t5
          physeq_egg_top80
          
          physeq_cloaca_top90_t5_noTrans <- physeq_cloaca_top90_t5
          physeq_cloaca_top90_t5_vst <- physeq_cloaca_top90_t5
          physeq_egg_top80_noTrans <- physeq_egg_top80
          physeq_egg_top80_vst <- physeq_egg_top80
          
          # store variance stabilised transformed otu table in _vst phyloseq objects
          otu_table(physeq_cloaca_top90_t5_vst) <- otu_table(assay(dds_physeq_cloaca_top90_t5), taxa_are_rows = TRUE)
          otu_table(physeq_egg_top80_vst) <- otu_table(assay(dds_egg80_compar_vst), taxa_are_rows = TRUE)
          
          otu_table(physeq_cloaca_top90_t5_vst)[1:5,1:5]
          otu_table(physeq_egg_top80_vst)[1:5,1:5]
          
          # set negative transformed values to ZERO (as they are estimated to be close to zero based on the fitted NegBin model: the more negative, the more likely to be true 0)          
          otu_table(physeq_egg_top80_vst)[otu_table(physeq_egg_top80_vst) < 0] <- 0
          otu_table(physeq_cloaca_top90_t5_vst)[otu_table(physeq_cloaca_top90_t5_vst) < 0] <- 0
          
          otu_table(physeq_cloaca_top90_t5_vst)[1:5,1:5]
          otu_table(physeq_egg_top80_vst)[1:5,1:5]
          
          
        ## Beta diversity analysis on original physeq objects
          df_physeq_cloaca_top90_t5_vst <- as.data.frame(sample_data(physeq_cloaca_top90_t5_vst)@.Data)
          df_physeq_egg_top80_vst <- as.data.frame(sample_data(physeq_egg_top80_vst)@.Data)
          colnames(df_physeq_cloaca_top90_t5_vst) <- sample_data(physeq_cloaca_top90_t5_vst)@names
          colnames(df_physeq_egg_top80_vst) <- sample_data(physeq_egg_top80_vst)@names
          
          physeq_cloaca_top90_t5_vst_wunifr <- UniFrac(physeq_cloaca_top90_t5_vst, weighted = T, normalized = T)
          physeq_cloaca_top90_t5_vst_uunifr <- UniFrac(physeq_cloaca_top90_t5_vst, weighted = F, normalized = F)
          egg80_vst_wunifr <- UniFrac(physeq_egg_top80_vst, weighted = T, normalized = T)
          egg80_vst_uunifr <- UniFrac(physeq_egg_top80_vst, weighted = F, normalized = F)
          
          physeq_cloaca_top90_t5_vst_bray <- vegdist(t(otu_table(physeq_cloaca_top90_t5_vst)), "bray")
          egg80_vst_bray <- vegdist(t(otu_table(physeq_egg_top80_vst)), "bray")

          # ordinations
          ord_physeq_cloaca_top90_t5_vst_wunifr <- ordinate(physeq_cloaca_top90_t5_vst, method="PCoA", distance = "wunifrac")
          ord_physeq_cloaca_top90_t5_vst_uunifr <- ordinate(physeq_cloaca_top90_t5_vst, method="PCoA", distance = "uunifrac")
          ord_physeq_cloaca_top90_t5_vst_bray <- ordinate(physeq_cloaca_top90_t5_vst, method="PCoA", distance = "bray")
          
          ord_egg80_vst_wunifr <- ordinate(physeq_egg_top80_vst, method="PCoA", distance = "wunifrac")
          ord_egg80_vst_uunifr <- ordinate(physeq_egg_top80_vst, method="PCoA", distance = "uunifrac")
          ord_egg80_vst_bray <- ordinate(physeq_egg_top80_vst, method="PCoA", distance = "bray")
          
          # plot ordinations
          p_physeq_cloaca_top90_t5_vst_wunifr <- plot_ordination(physeq_cloaca_top90_t5_vst, ord_physeq_cloaca_top90_t5_vst_wunifr, axes = c(1,2), color="exp",shape="exp", type = "Samples", title = "weighted UniFrac - all samples" )
          p_physeq_cloaca_top90_t5_vst_uunifr <- plot_ordination(physeq_cloaca_top90_t5_vst, ord_physeq_cloaca_top90_t5_vst_uunifr, axes = c(1,2), color="exp",shape="exp", type = "Samples", title = "unweighted UniFrac - all samples" )
          p_physeq_cloaca_top90_t5_vst_bray <- plot_ordination(physeq_cloaca_top90_t5_vst, ord_physeq_cloaca_top90_t5_vst_bray, axes = c(1,2), color="exp", shape = "exp", type = "Samples", title = "Bray Curtis - all samples" )
          
          pdf("Fig_S1_unweighted_UniFrac_cloacal_top90_vst_t5.pdf", useDingbats = F, width = 8, height = 3)
          grid.arrange(p_physeq_cloaca_top90_t5_vst_wunifr, p_physeq_cloaca_top90_t5_vst_uunifr, nrow=1, ncol = 2)
          dev.off()
          
          # adonis to test effect of experiment on female microbiome
          cloaca_top90_t5_vst_wunifr <- UniFrac(physeq_cloaca_top90_t5_vst, weighted = T, normalized = T)
          cloaca_top90_t5_vst_uunifr <- UniFrac(physeq_cloaca_top90_t5_vst, weighted = F, normalized = F)
          cloaca_top90_t5_vst_bray <- vegdist(t(otu_table(physeq_cloaca_top90_t5_vst)), "bray")
          
          adonis(cloaca_top90_t5_vst_wunifr ~ exp, data =df_physeq_cloaca_top90_t5_vst)
          
              Call:
                adonis(formula = cloaca_top90_t5_vst_wunifr ~ exp, data = df_physeq_cloaca_top90_t5_vst) 
              
              Permutation: free
              Number of permutations: 999
              
              Terms added sequentially (first to last)
              
              Df SumsOfSqs  MeanSqs F.Model     R2 Pr(>F)
              exp        1   0.04336 0.043362  1.3701 0.0348  0.244
              Residuals 38   1.20262 0.031648         0.9652       
              Total     39   1.24598                  1.0000
              
              
          adonis(cloaca_top90_t5_vst_uunifr ~ exp, data =df_physeq_cloaca_top90_t5_vst)
          
              Call:
                adonis(formula = cloaca_top90_t5_vst_uunifr ~ exp, data = df_physeq_cloaca_top90_t5_vst) 
              
              Permutation: free
              Number of permutations: 999
              
              Terms added sequentially (first to last)
              
              Df SumsOfSqs MeanSqs F.Model      R2 Pr(>F)
              exp        1    0.1832 0.18317  1.0498 0.02688  0.392
              Residuals 38    6.6302 0.17448         0.97312       
              Total     39    6.8134                 1.00000       
          
          
          adonis(cloaca_top90_t5_vst_bray ~ exp, data =df_physeq_cloaca_top90_t5_vst)
              
              Call:
                adonis(formula = cloaca_top90_t5_vst_bray ~ exp, data = df_physeq_cloaca_top90_t5_vst) 
              
              Permutation: free
              Number of permutations: 999
              
              Terms added sequentially (first to last)
              
              Df SumsOfSqs MeanSqs F.Model      R2 Pr(>F)
              exp        1    0.1604 0.16045 0.58926 0.01527  0.899
              Residuals 38   10.3468 0.27228         0.98473       
              Total     39   10.5072                 1.00000  
              
              
              
              # how many eggs?
                summ_egg_data <- summaryBy(NumberID ~ exp+clutch_nr + egg_nr, data = data_egg_immunity_allnoNA, FUN = function(x) {c(m = mean(x), r = range(x), med = median(x), n = length(x), s = sd(x), sem = sd(x)/sqrt(length(x)))})
                data_egg_immunity_allnoNA3 <- subset(data_egg_immunity_allnoNA, clutch_nr == "1" | clutch_nr == "2" | clutch_nr == "3")
                
              summ_egg_data_lyso <- summaryBy(NumberID ~ exp+clutch_nr + egg_nr, data = subset(data_egg_immunity_allnoNA, !is.na(lyso)), FUN = function(x) {c(m = mean(x), r = range(x), med = median(x), n = length(x), s = sd(x), sem = sd(x)/sqrt(length(x)))})
              summ_egg_data_ovo <- summaryBy(NumberID ~ exp+clutch_nr + egg_nr, data = subset(data_egg_immunity_allnoNA, !is.na(ovotransferrin)), FUN = function(x) {c(m = mean(x), r = range(x), med = median(x), n = length(x), s = sd(x), sem = sd(x)/sqrt(length(x)))})
              summ_egg_data_IgY_yolk <- summaryBy(NumberID ~ exp+clutch_nr + egg_nr, data = subset(data_egg_immunity_allnoNA, !is.na(IgYmean_yolk)), FUN = function(x) {c(m = mean(x), r = range(x), med = median(x), n = length(x), s = sd(x), sem = sd(x)/sqrt(length(x)))})
              summ_egg_data_IgY_noNA <- summaryBy(NumberID ~ exp+clutch_nr + egg_nr, data = data_egg_immunity_allnoNA3, FUN = function(x) {c(m = mean(x), r = range(x), med = median(x), n = length(x), s = sd(x), sem = sd(x)/sqrt(length(x)))})
              
              data_egg_immunity_allnoNA
              